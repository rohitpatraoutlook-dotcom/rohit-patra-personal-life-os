from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("api/finance/", include("apps.finance.urls")),
    path("api/jobtracker/", include("apps.jobtracker.urls")),
    path("api/career/", include("apps.career.urls")),
    path("api/", include("apps.projects.urls")),
    path("api/", include("apps.notes.urls")),
    path("api/", include("apps.goals.urls")),
    path("api/", include("apps.tasks.urls")),
    path("admin/", admin.site.urls),
    path("", include("apps.accounts.urls")),
]
