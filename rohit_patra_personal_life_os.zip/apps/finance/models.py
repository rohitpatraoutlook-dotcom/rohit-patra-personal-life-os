from decimal import Decimal

from django.conf import settings
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models
from django.db.models import Q


class Transaction(models.Model):
    INCOME = "income"
    EXPENSE = "expense"

    TRANSACTION_TYPES = [
        (INCOME, "Income"),
        (EXPENSE, "Expense"),
    ]

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="finance_transactions",
    )
    transaction_type = models.CharField(
        max_length=10,
        choices=TRANSACTION_TYPES,
    )
    title = models.CharField(max_length=200)
    amount = models.DecimalField(
        max_digits=14,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    category = models.CharField(max_length=100)
    date = models.DateField()
    payment_method = models.CharField(max_length=50, blank=True)
    notes = models.TextField(blank=True)
    currency = models.CharField(max_length=3, default="INR")
    is_archived = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-date", "-created_at"]
        indexes = [
            models.Index(fields=["owner", "date"]),
            models.Index(fields=["owner", "transaction_type"]),
            models.Index(fields=["owner", "category"]),
        ]
        constraints = [
            models.CheckConstraint(
                condition=Q(amount__gt=0),
                name="finance_transaction_amount_positive",
            ),
        ]

    def __str__(self):
        return f"{self.title} - {self.amount} {self.currency}"


class MonthlyBudget(models.Model):
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="finance_budgets",
    )
    year = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(2000), MaxValueValidator(2200)],
    )
    month = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(12)],
    )
    category = models.CharField(max_length=100)
    limit_amount = models.DecimalField(
        max_digits=14,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    currency = models.CharField(max_length=3, default="INR")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-year", "-month", "category"]
        constraints = [
            models.UniqueConstraint(
                fields=["owner", "year", "month", "category"],
                name="unique_owner_monthly_category_budget",
            ),
            models.CheckConstraint(
                condition=Q(month__gte=1) & Q(month__lte=12),
                name="finance_budget_month_valid",
            ),
            models.CheckConstraint(
                condition=Q(limit_amount__gt=0),
                name="finance_budget_limit_positive",
            ),
        ]

    def __str__(self):
        return f"{self.category} - {self.month}/{self.year}"


class SavingsGoal(models.Model):
    ACTIVE = "active"
    COMPLETED = "completed"
    PAUSED = "paused"

    STATUSES = [
        (ACTIVE, "Active"),
        (COMPLETED, "Completed"),
        (PAUSED, "Paused"),
    ]

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="finance_savings_goals",
    )
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    target_amount = models.DecimalField(
        max_digits=14,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    current_amount = models.DecimalField(
        max_digits=14,
        decimal_places=2,
        default=Decimal("0.00"),
        validators=[MinValueValidator(Decimal("0.00"))],
    )
    target_date = models.DateField(null=True, blank=True)
    status = models.CharField(
        max_length=10,
        choices=STATUSES,
        default=ACTIVE,
    )
    currency = models.CharField(max_length=3, default="INR")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["target_date", "-created_at"]
        constraints = [
            models.CheckConstraint(
                condition=Q(target_amount__gt=0),
                name="finance_savings_target_positive",
            ),
            models.CheckConstraint(
                condition=Q(current_amount__gte=0),
                name="finance_savings_current_nonnegative",
            ),
        ]

    @property
    def progress_percentage(self):
        if self.target_amount <= 0:
            return 0
        percentage = (self.current_amount / self.target_amount) * 100
        return min(float(percentage), 100.0)

    @property
    def remaining_amount(self):
        return max(
            self.target_amount - self.current_amount,
            Decimal("0.00"),
        )

    def __str__(self):
        return self.title
