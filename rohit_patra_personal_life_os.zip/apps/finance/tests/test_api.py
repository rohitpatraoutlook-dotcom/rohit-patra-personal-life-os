import json
from datetime import date
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from apps.finance.models import Transaction, MonthlyBudget, SavingsGoal

User = get_user_model()


class FinanceTransactionAPITests(TestCase):

    def setUp(self):
        self.user = User.objects.create_user(
            username="finance_user",
            password="StrongTestPassword123!",
        )
        self.other_user = User.objects.create_user(
            username="other_finance_user",
            password="StrongTestPassword123!",
        )
        self.client.force_login(self.user)

        self.transactions_url = reverse("finance:transactions")
        self.overview_url = reverse("finance:overview")

    def create_transaction(
        self,
        owner=None,
        transaction_type="expense",
        title="Groceries",
        amount="500.00",
        category="Food",
        transaction_date=None,
    ):
        return Transaction.objects.create(
            owner=owner or self.user,
            transaction_type=transaction_type,
            title=title,
            amount=Decimal(amount),
            category=category,
            date=transaction_date or date(2026, 10, 10),
        )

    def test_unauthenticated_user_cannot_list_transactions(self):
        self.client.logout()

        response = self.client.get(self.transactions_url)

        self.assertEqual(response.status_code, 401)

    def test_create_income_transaction(self):
        response = self.client.post(
            self.transactions_url,
            data=json.dumps({
                "transaction_type": "income",
                "title": "Monthly Salary",
                "amount": "25000.00",
                "category": "Salary",
                "date": "2026-10-01",
            }),
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 201)
        self.assertEqual(Transaction.objects.count(), 1)

        transaction = Transaction.objects.get()
        self.assertEqual(transaction.owner, self.user)
        self.assertEqual(transaction.amount, Decimal("25000.00"))
        self.assertEqual(transaction.transaction_type, "income")

    def test_create_expense_transaction(self):
        response = self.client.post(
            self.transactions_url,
            data=json.dumps({
                "transaction_type": "expense",
                "title": "Electricity Bill",
                "amount": "1200.50",
                "category": "Bills",
                "date": "2026-10-05",
            }),
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 201)
        self.assertEqual(
            Transaction.objects.get().amount,
            Decimal("1200.50"),
        )

    def test_reject_zero_amount(self):
        response = self.client.post(
            self.transactions_url,
            data=json.dumps({
                "transaction_type": "expense",
                "title": "Invalid Expense",
                "amount": "0",
                "category": "Food",
                "date": "2026-10-10",
            }),
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 400)
        self.assertEqual(Transaction.objects.count(), 0)

    def test_reject_negative_amount(self):
        response = self.client.post(
            self.transactions_url,
            data=json.dumps({
                "transaction_type": "expense",
                "title": "Invalid Expense",
                "amount": "-10",
                "category": "Food",
                "date": "2026-10-10",
            }),
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 400)

    def test_reject_invalid_transaction_type(self):
        response = self.client.post(
            self.transactions_url,
            data=json.dumps({
                "transaction_type": "transfer",
                "title": "Transfer",
                "amount": "100",
                "category": "Other",
                "date": "2026-10-10",
            }),
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 400)

    def test_user_only_sees_own_transactions(self):
        own = self.create_transaction(title="My Expense")
        other = self.create_transaction(
            owner=self.other_user,
            title="Other User Expense",
        )

        response = self.client.get(self.transactions_url)

        self.assertEqual(response.status_code, 200)

        results = response.json()["results"]
        result_ids = [item["id"] for item in results]

        self.assertIn(own.id, result_ids)
        self.assertNotIn(other.id, result_ids)

    def test_cannot_read_another_users_transaction(self):
        other = self.create_transaction(owner=self.other_user)

        response = self.client.get(
            reverse(
                "finance:transaction-detail",
                kwargs={"transaction_id": other.id},
            )
        )

        self.assertEqual(response.status_code, 404)

    def test_cannot_update_another_users_transaction(self):
        other = self.create_transaction(owner=self.other_user)

        response = self.client.patch(
            reverse(
                "finance:transaction-detail",
                kwargs={"transaction_id": other.id},
            ),
            data=json.dumps({"title": "Unauthorized Change"}),
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 404)

        other.refresh_from_db()
        self.assertEqual(other.title, "Groceries")

    def test_cannot_delete_another_users_transaction(self):
        other = self.create_transaction(owner=self.other_user)

        response = self.client.delete(
            reverse(
                "finance:transaction-detail",
                kwargs={"transaction_id": other.id},
            )
        )

        self.assertEqual(response.status_code, 404)
        self.assertTrue(
            Transaction.objects.filter(id=other.id).exists()
        )

    def test_update_own_transaction(self):
        transaction = self.create_transaction()

        response = self.client.patch(
            reverse(
                "finance:transaction-detail",
                kwargs={"transaction_id": transaction.id},
            ),
            data=json.dumps({
                "title": "Updated Groceries",
                "amount": "650.00",
            }),
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 200)

        transaction.refresh_from_db()
        self.assertEqual(transaction.title, "Updated Groceries")
        self.assertEqual(transaction.amount, Decimal("650.00"))

    def test_delete_own_transaction(self):
        transaction = self.create_transaction()

        response = self.client.delete(
            reverse(
                "finance:transaction-detail",
                kwargs={"transaction_id": transaction.id},
            )
        )

        self.assertEqual(response.status_code, 200)
        self.assertFalse(
            Transaction.objects.filter(id=transaction.id).exists()
        )

    def test_monthly_overview_calculates_totals(self):
        self.create_transaction(
            transaction_type="income",
            title="Salary",
            amount="30000.00",
            category="Salary",
            transaction_date=date(2026, 10, 1),
        )
        self.create_transaction(
            transaction_type="expense",
            title="Food",
            amount="2000.00",
            category="Food",
            transaction_date=date(2026, 10, 5),
        )
        self.create_transaction(
            transaction_type="expense",
            title="Travel",
            amount="1000.00",
            category="Travel",
            transaction_date=date(2026, 10, 7),
        )

        response = self.client.get(
            self.overview_url,
            {"year": 2026, "month": 10},
        )

        self.assertEqual(response.status_code, 200)
        data = response.json()

        self.assertEqual(data["total_income"], "30000.00")
        self.assertEqual(data["total_expenses"], "3000.00")
        self.assertEqual(data["net_balance"], "27000.00")

    def test_monthly_overview_excludes_other_users(self):
        self.create_transaction(
            transaction_type="income",
            amount="10000.00",
            title="My Salary",
        )
        self.create_transaction(
            owner=self.other_user,
            transaction_type="income",
            amount="90000.00",
            title="Other Salary",
        )

        response = self.client.get(
            self.overview_url,
            {"year": 2026, "month": 10},
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.json()["total_income"],
            "10000.00",
        )

    def test_invalid_month_is_rejected(self):
        response = self.client.get(
            self.overview_url,
            {"year": 2026, "month": 13},
        )

        self.assertEqual(response.status_code, 400)


class FinanceBudgetAndSavingsTests(TestCase):

    def setUp(self):
        self.user = User.objects.create_user(
            username="budget_user",
            password="StrongTestPassword123!",
        )
        self.other_user = User.objects.create_user(
            username="budget_other_user",
            password="StrongTestPassword123!",
        )
        self.client.force_login(self.user)

    def post_json(self, url, data):
        return self.client.post(
            url,
            data=json.dumps(data),
            content_type="application/json",
        )

    def test_create_monthly_budget(self):
        response = self.post_json(
            reverse("finance:budgets"),
            {
                "year": 2026,
                "month": 10,
                "category": "Food",
                "limit_amount": "5000.00",
            },
        )

        self.assertEqual(response.status_code, 201)
        self.assertEqual(MonthlyBudget.objects.count(), 1)
        self.assertEqual(
            MonthlyBudget.objects.get().owner,
            self.user,
        )

    def test_duplicate_monthly_budget_rejected(self):
        MonthlyBudget.objects.create(
            owner=self.user,
            year=2026,
            month=10,
            category="Food",
            limit_amount=Decimal("5000.00"),
        )

        response = self.post_json(
            reverse("finance:budgets"),
            {
                "year": 2026,
                "month": 10,
                "category": "Food",
                "limit_amount": "6000.00",
            },
        )

        self.assertEqual(response.status_code, 409)
        self.assertEqual(MonthlyBudget.objects.count(), 1)

    def test_budget_list_contains_only_own_budgets(self):
        own = MonthlyBudget.objects.create(
            owner=self.user,
            year=2026,
            month=10,
            category="Food",
            limit_amount=Decimal("5000.00"),
        )

        other = MonthlyBudget.objects.create(
            owner=self.other_user,
            year=2026,
            month=10,
            category="Travel",
            limit_amount=Decimal("2000.00"),
        )

        response = self.client.get(reverse("finance:budgets"))

        self.assertEqual(response.status_code, 200)
        ids = [item["id"] for item in response.json()["results"]]
        self.assertIn(own.id, ids)
        self.assertNotIn(other.id, ids)

    def test_cannot_access_another_users_budget(self):
        other = MonthlyBudget.objects.create(
            owner=self.other_user,
            year=2026,
            month=10,
            category="Travel",
            limit_amount=Decimal("2000.00"),
        )

        response = self.client.get(
            reverse(
                "finance:budget-detail",
                kwargs={"budget_id": other.id},
            )
        )

        self.assertEqual(response.status_code, 404)

    def test_create_savings_goal(self):
        response = self.post_json(
            reverse("finance:savings-goals"),
            {
                "title": "Emergency Fund",
                "target_amount": "100000.00",
                "current_amount": "25000.00",
                "target_date": "2027-12-31",
            },
        )

        self.assertEqual(response.status_code, 201)

        goal = SavingsGoal.objects.get()
        self.assertEqual(goal.owner, self.user)
        self.assertEqual(goal.target_amount, Decimal("100000.00"))
        self.assertEqual(goal.current_amount, Decimal("25000.00"))

        self.assertEqual(
            response.json()["progress_percentage"],
            25.0,
        )
        self.assertEqual(
            response.json()["remaining_amount"],
            "75000.00",
        )

    def test_savings_goal_update(self):
        goal = SavingsGoal.objects.create(
            owner=self.user,
            title="New Phone",
            target_amount=Decimal("20000.00"),
            current_amount=Decimal("5000.00"),
        )

        response = self.client.patch(
            reverse(
                "finance:savings-goal-detail",
                kwargs={"goal_id": goal.id},
            ),
            data=json.dumps({
                "current_amount": "10000.00",
                "status": "active",
            }),
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 200)

        goal.refresh_from_db()
        self.assertEqual(
            goal.current_amount,
            Decimal("10000.00"),
        )

    def test_savings_goal_rejects_negative_target(self):
        response = self.post_json(
            reverse("finance:savings-goals"),
            {
                "title": "Invalid Goal",
                "target_amount": "-500",
            },
        )

        self.assertEqual(response.status_code, 400)
        self.assertEqual(SavingsGoal.objects.count(), 0)

    def test_cannot_read_another_users_savings_goal(self):
        goal = SavingsGoal.objects.create(
            owner=self.other_user,
            title="Private Savings",
            target_amount=Decimal("50000.00"),
        )

        response = self.client.get(
            reverse(
                "finance:savings-goal-detail",
                kwargs={"goal_id": goal.id},
            )
        )

        self.assertEqual(response.status_code, 404)

    def test_unauthenticated_budget_access_rejected(self):
        self.client.logout()

        response = self.client.get(reverse("finance:budgets"))

        self.assertEqual(response.status_code, 401)

    def test_unauthenticated_savings_access_rejected(self):
        self.client.logout()

        response = self.client.get(reverse("finance:savings-goals"))

        self.assertEqual(response.status_code, 401)
