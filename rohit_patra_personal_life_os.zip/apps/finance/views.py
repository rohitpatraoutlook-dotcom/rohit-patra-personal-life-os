import json
from datetime import date
from decimal import Decimal, InvalidOperation
from functools import wraps

from django.db import IntegrityError
from django.db.models import Sum
from django.http import JsonResponse
from django.utils.dateparse import parse_date
from django.views.decorators.http import require_http_methods

from .models import Transaction, MonthlyBudget, SavingsGoal


def finance_api_login_required(view_func):
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return JsonResponse(
                {"error": "Authentication required."},
                status=401,
            )
        return view_func(request, *args, **kwargs)
    return wrapper


def read_json(request):
    try:
        data = json.loads(request.body or b"{}")
        if not isinstance(data, dict):
            return None, "JSON body must be an object."
        return data, None
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None, "Invalid JSON."


def positive_amount(value, allow_zero=False):
    try:
        amount = Decimal(str(value))

        if not amount.is_finite():
            return None

        if allow_zero:
            if amount < 0:
                return None
        elif amount <= 0:
            return None

        if amount.as_tuple().exponent < -2:
            return None

        if amount > Decimal("999999999999.99"):
            return None

        return amount

    except (InvalidOperation, ValueError, TypeError):
        return None


def valid_text(value, field, required=False, max_length=None):
    if value is None:
        value = ""

    if not isinstance(value, str):
        raise ValueError(f"{field} must be text.")

    value = value.strip()

    if required and not value:
        raise ValueError(f"{field} is required.")

    if max_length and len(value) > max_length:
        raise ValueError(
            f"{field} cannot exceed {max_length} characters."
        )

    return value


def parse_optional_date(value, field):
    if value in (None, ""):
        return None

    if not isinstance(value, str):
        raise ValueError(f"{field} must use YYYY-MM-DD format.")

    result = parse_date(value)

    if result is None:
        raise ValueError(f"{field} must use YYYY-MM-DD format.")

    return result


def validate_currency(value):
    if not isinstance(value, str):
        return None

    value = value.strip().upper()

    if len(value) != 3 or not value.isalpha():
        return None

    return value


def serialize_transaction(obj):
    return {
        "id": obj.id,
        "transaction_type": obj.transaction_type,
        "title": obj.title,
        "amount": str(obj.amount),
        "category": obj.category,
        "date": obj.date.isoformat(),
        "payment_method": obj.payment_method,
        "notes": obj.notes,
        "currency": obj.currency,
        "is_archived": obj.is_archived,
        "created_at": obj.created_at.isoformat(),
        "updated_at": obj.updated_at.isoformat(),
    }


@finance_api_login_required
@require_http_methods(["GET", "POST"])
def transactions_api(request):

    # GET: list and filter transactions
    if request.method == "GET":
        qs = Transaction.objects.filter(owner=request.user)

        transaction_type = request.GET.get("type")
        category = request.GET.get("category")
        search = request.GET.get("q")
        start_date = request.GET.get("start_date")
        end_date = request.GET.get("end_date")
        archived = request.GET.get("archived", "false").lower()

        if transaction_type:
            if transaction_type not in ("income", "expense"):
                return JsonResponse(
                    {"error": "Invalid transaction type."},
                    status=400,
                )

            qs = qs.filter(transaction_type=transaction_type)

        if category:
            qs = qs.filter(category__iexact=category)

        if search:
            qs = qs.filter(
                title__icontains=search
            ) | qs.filter(
                category__icontains=search
            )

        # Keep the query restricted to the logged-in owner.
        qs = qs.filter(owner=request.user)

        if archived not in ("true", "false"):
            return JsonResponse(
                {"error": "archived must be true or false."},
                status=400,
            )

        qs = qs.filter(is_archived=(archived == "true"))

        if start_date:
            parsed = parse_date(start_date)
            if parsed is None:
                return JsonResponse(
                    {"error": "Invalid start_date."},
                    status=400,
                )
            qs = qs.filter(date__gte=parsed)

        if end_date:
            parsed = parse_date(end_date)
            if parsed is None:
                return JsonResponse(
                    {"error": "Invalid end_date."},
                    status=400,
                )
            qs = qs.filter(date__lte=parsed)

        if start_date and end_date and start_date > end_date:
            return JsonResponse(
                {"error": "start_date must not exceed end_date."},
                status=400,
            )

        results = [
            serialize_transaction(obj)
            for obj in qs
        ]

        return JsonResponse({
            "results": results,
            "count": len(results),
        })

    # POST: create a transaction
    data, error = read_json(request)

    if error:
        return JsonResponse({"error": error}, status=400)

    try:
        transaction_type = data.get("transaction_type")

        if transaction_type not in ("income", "expense"):
            raise ValueError(
                "transaction_type must be income or expense."
            )

        title = valid_text(
            data.get("title"), "title", True, 200
        )

        category = valid_text(
            data.get("category"), "category", True, 100
        )

        amount = positive_amount(data.get("amount"))

        if amount is None:
            raise ValueError(
                "amount must be positive with at most 2 decimal places."
            )

        transaction_date = parse_optional_date(
            data.get("date"), "date"
        )

        if transaction_date is None:
            raise ValueError(
                "date is required in YYYY-MM-DD format."
            )

        currency = validate_currency(
            data.get("currency", "INR")
        )

        if currency is None:
            raise ValueError(
                "currency must be a 3-letter code."
            )

        payment_method = valid_text(
            data.get("payment_method"),
            "payment_method",
            max_length=50,
        )

        notes = valid_text(data.get("notes"), "notes")

        obj = Transaction.objects.create(
            owner=request.user,
            transaction_type=transaction_type,
            title=title,
            amount=amount,
            category=category,
            date=transaction_date,
            payment_method=payment_method,
            notes=notes,
            currency=currency,
        )

        return JsonResponse(
            serialize_transaction(obj),
            status=201,
        )

    except (ValueError, TypeError) as exc:
        return JsonResponse({"error": str(exc)}, status=400)


@finance_api_login_required
@require_http_methods(["GET", "PATCH", "DELETE"])
def transaction_detail_api(request, transaction_id):

    # Users can access only their own transactions.
    obj = Transaction.objects.filter(
        owner=request.user,
        id=transaction_id,
    ).first()

    if obj is None:
        return JsonResponse(
            {"error": "Transaction not found."},
            status=404,
        )

    if request.method == "GET":
        return JsonResponse(serialize_transaction(obj))

    if request.method == "DELETE":
        obj.delete()
        return JsonResponse({
            "message": "Transaction deleted."
        })

    data, error = read_json(request)

    if error:
        return JsonResponse({"error": error}, status=400)

    try:
        if "transaction_type" in data:
            if data["transaction_type"] not in ("income", "expense"):
                raise ValueError("Invalid transaction_type.")

            obj.transaction_type = data["transaction_type"]

        if "title" in data:
            obj.title = valid_text(
                data["title"], "title", True, 200
            )

        if "category" in data:
            obj.category = valid_text(
                data["category"], "category", True, 100
            )

        if "amount" in data:
            amount = positive_amount(data["amount"])

            if amount is None:
                raise ValueError(
                    "amount must be positive with at most 2 decimal places."
                )

            obj.amount = amount

        if "date" in data:
            parsed = parse_optional_date(data["date"], "date")

            if parsed is None:
                raise ValueError("date cannot be empty.")

            obj.date = parsed

        if "payment_method" in data:
            obj.payment_method = valid_text(
                data["payment_method"],
                "payment_method",
                max_length=50,
            )

        if "notes" in data:
            obj.notes = valid_text(data["notes"], "notes")

        if "currency" in data:
            currency = validate_currency(data["currency"])

            if currency is None:
                raise ValueError(
                    "currency must be a 3-letter code."
                )

            obj.currency = currency

        if "is_archived" in data:
            if not isinstance(data["is_archived"], bool):
                raise ValueError(
                    "is_archived must be true or false."
                )

            obj.is_archived = data["is_archived"]

        obj.save()

        return JsonResponse(serialize_transaction(obj))

    except (ValueError, TypeError) as exc:
        return JsonResponse({"error": str(exc)}, status=400)


# ==================================================
# MONTHLY BUDGETS API
# ==================================================

def serialize_budget(obj):
    return {
        "id": obj.id,
        "year": obj.year,
        "month": obj.month,
        "category": obj.category,
        "limit_amount": str(obj.limit_amount),
        "currency": obj.currency,
        "created_at": obj.created_at.isoformat(),
        "updated_at": obj.updated_at.isoformat(),
    }


@finance_api_login_required
@require_http_methods(["GET", "POST"])
def budgets_api(request):

    if request.method == "GET":
        qs = MonthlyBudget.objects.filter(owner=request.user)

        year = request.GET.get("year")
        month = request.GET.get("month")
        category = request.GET.get("category")

        try:
            if year:
                year_number = int(year)
                if not 2000 <= year_number <= 2200:
                    raise ValueError
                qs = qs.filter(year=year_number)

            if month:
                month_number = int(month)
                if not 1 <= month_number <= 12:
                    raise ValueError
                qs = qs.filter(month=month_number)

        except (ValueError, TypeError):
            return JsonResponse(
                {"error": "Invalid year or month."},
                status=400,
            )

        if category:
            qs = qs.filter(category__iexact=category)

        results = [serialize_budget(obj) for obj in qs]

        return JsonResponse({
            "results": results,
            "count": len(results),
        })

    data, error = read_json(request)

    if error:
        return JsonResponse({"error": error}, status=400)

    try:
        year = int(data.get("year"))
        month = int(data.get("month"))

        if not 2000 <= year <= 2200:
            raise ValueError("Year must be between 2000 and 2200.")

        if not 1 <= month <= 12:
            raise ValueError("Month must be between 1 and 12.")

        category = valid_text(
            data.get("category"),
            "category",
            required=True,
            max_length=100,
        )

        amount = positive_amount(data.get("limit_amount"))

        if amount is None:
            raise ValueError(
                "limit_amount must be positive with at most 2 decimal places."
            )

        currency = validate_currency(data.get("currency", "INR"))

        if currency is None:
            raise ValueError("currency must be a 3-letter code.")

        # Prevent duplicate category budgets for the same owner/month.
        if MonthlyBudget.objects.filter(
            owner=request.user,
            year=year,
            month=month,
            category__iexact=category,
        ).exists():
            return JsonResponse(
                {"error": "A budget already exists for this category and month."},
                status=409,
            )

        obj = MonthlyBudget.objects.create(
            owner=request.user,
            year=year,
            month=month,
            category=category,
            limit_amount=amount,
            currency=currency,
        )

        return JsonResponse(serialize_budget(obj), status=201)

    except (ValueError, TypeError) as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    except IntegrityError:
        return JsonResponse(
            {"error": "A budget already exists for this category and month."},
            status=409,
        )


@finance_api_login_required
@require_http_methods(["GET", "PATCH", "DELETE"])
def budget_detail_api(request, budget_id):

    obj = MonthlyBudget.objects.filter(
        owner=request.user,
        id=budget_id,
    ).first()

    if obj is None:
        return JsonResponse(
            {"error": "Budget not found."},
            status=404,
        )

    if request.method == "GET":
        return JsonResponse(serialize_budget(obj))

    if request.method == "DELETE":
        obj.delete()
        return JsonResponse({"message": "Budget deleted."})

    data, error = read_json(request)

    if error:
        return JsonResponse({"error": error}, status=400)

    try:
        if "year" in data:
            year = int(data["year"])

            if not 2000 <= year <= 2200:
                raise ValueError("Year must be between 2000 and 2200.")

            obj.year = year

        if "month" in data:
            month = int(data["month"])

            if not 1 <= month <= 12:
                raise ValueError("Month must be between 1 and 12.")

            obj.month = month

        if "category" in data:
            obj.category = valid_text(
                data["category"],
                "category",
                required=True,
                max_length=100,
            )

        if "limit_amount" in data:
            amount = positive_amount(data["limit_amount"])

            if amount is None:
                raise ValueError(
                    "limit_amount must be positive with at most 2 decimal places."
                )

            obj.limit_amount = amount

        if "currency" in data:
            currency = validate_currency(data["currency"])

            if currency is None:
                raise ValueError("currency must be a 3-letter code.")

            obj.currency = currency

        # Check for a conflicting budget before saving.
        duplicate = MonthlyBudget.objects.filter(
            owner=request.user,
            year=obj.year,
            month=obj.month,
            category__iexact=obj.category,
        ).exclude(id=obj.id).exists()

        if duplicate:
            return JsonResponse(
                {"error": "A budget already exists for this category and month."},
                status=409,
            )

        obj.save()

        return JsonResponse(serialize_budget(obj))

    except (ValueError, TypeError) as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    except IntegrityError:
        return JsonResponse(
            {"error": "A budget already exists for this category and month."},
            status=409,
        )


# ==================================================
# SAVINGS GOALS API
# ==================================================

def serialize_savings_goal(obj):
    return {
        "id": obj.id,
        "title": obj.title,
        "description": obj.description,
        "target_amount": str(obj.target_amount),
        "current_amount": str(obj.current_amount),
        "remaining_amount": str(obj.remaining_amount),
        "progress_percentage": round(obj.progress_percentage, 2),
        "target_date": (
            obj.target_date.isoformat()
            if obj.target_date else None
        ),
        "status": obj.status,
        "currency": obj.currency,
        "created_at": obj.created_at.isoformat(),
        "updated_at": obj.updated_at.isoformat(),
    }


@finance_api_login_required
@require_http_methods(["GET", "POST"])
def savings_goals_api(request):

    # GET: list and search the current user's savings goals
    if request.method == "GET":
        qs = SavingsGoal.objects.filter(owner=request.user)

        status = request.GET.get("status")
        search = request.GET.get("q")

        if status:
            if status not in ("active", "completed", "paused"):
                return JsonResponse(
                    {"error": "Invalid savings goal status."},
                    status=400,
                )

            qs = qs.filter(status=status)

        if search:
            qs = qs.filter(title__icontains=search)

        results = [
            serialize_savings_goal(obj)
            for obj in qs
        ]

        return JsonResponse({
            "results": results,
            "count": len(results),
        })

    # POST: create a new savings goal
    data, error = read_json(request)

    if error:
        return JsonResponse({"error": error}, status=400)

    try:
        title = valid_text(
            data.get("title"),
            "title",
            required=True,
            max_length=200,
        )

        description = valid_text(
            data.get("description"),
            "description",
        )

        target = positive_amount(data.get("target_amount"))

        if target is None:
            raise ValueError(
                "target_amount must be positive with at most 2 decimal places."
            )

        current = positive_amount(
            data.get("current_amount", "0"),
            allow_zero=True,
        )

        if current is None:
            raise ValueError(
                "current_amount must be non-negative with at most 2 decimal places."
            )

        status = data.get("status", "active")

        if status not in ("active", "completed", "paused"):
            raise ValueError(
                "status must be active, completed or paused."
            )

        target_date = parse_optional_date(
            data.get("target_date"),
            "target_date",
        )

        currency = validate_currency(
            data.get("currency", "INR")
        )

        if currency is None:
            raise ValueError("currency must be a 3-letter code.")

        obj = SavingsGoal.objects.create(
            owner=request.user,
            title=title,
            description=description,
            target_amount=target,
            current_amount=current,
            target_date=target_date,
            status=status,
            currency=currency,
        )

        return JsonResponse(
            serialize_savings_goal(obj),
            status=201,
        )

    except (ValueError, TypeError) as exc:
        return JsonResponse({"error": str(exc)}, status=400)


@finance_api_login_required
@require_http_methods(["GET", "PATCH", "DELETE"])
def savings_goal_detail_api(request, goal_id):

    # Owner-only access
    obj = SavingsGoal.objects.filter(
        owner=request.user,
        id=goal_id,
    ).first()

    if obj is None:
        return JsonResponse(
            {"error": "Savings goal not found."},
            status=404,
        )

    if request.method == "GET":
        return JsonResponse(serialize_savings_goal(obj))

    if request.method == "DELETE":
        obj.delete()

        return JsonResponse({
            "message": "Savings goal deleted."
        })

    data, error = read_json(request)

    if error:
        return JsonResponse({"error": error}, status=400)

    try:
        if "title" in data:
            obj.title = valid_text(
                data["title"],
                "title",
                required=True,
                max_length=200,
            )

        if "description" in data:
            obj.description = valid_text(
                data["description"],
                "description",
            )

        if "target_amount" in data:
            target = positive_amount(data["target_amount"])

            if target is None:
                raise ValueError(
                    "target_amount must be positive with at most 2 decimal places."
                )

            obj.target_amount = target

        if "current_amount" in data:
            current = positive_amount(
                data["current_amount"],
                allow_zero=True,
            )

            if current is None:
                raise ValueError(
                    "current_amount must be non-negative with at most 2 decimal places."
                )

            obj.current_amount = current

        if "target_date" in data:
            obj.target_date = parse_optional_date(
                data["target_date"],
                "target_date",
            )

        if "status" in data:
            if data["status"] not in (
                "active",
                "completed",
                "paused",
            ):
                raise ValueError(
                    "status must be active, completed or paused."
                )

            obj.status = data["status"]

        if "currency" in data:
            currency = validate_currency(data["currency"])

            if currency is None:
                raise ValueError(
                    "currency must be a 3-letter code."
                )

            obj.currency = currency

        obj.save()

        return JsonResponse(serialize_savings_goal(obj))

    except (ValueError, TypeError) as exc:
        return JsonResponse({"error": str(exc)}, status=400)


# ==================================================
# MONTHLY FINANCE OVERVIEW
# ==================================================

@finance_api_login_required
@require_http_methods(["GET"])
def finance_overview_api(request):
    today = date.today()

    try:
        year = int(request.GET.get("year", today.year))
        month = int(request.GET.get("month", today.month))

        if not 2000 <= year <= 2200:
            raise ValueError

        if not 1 <= month <= 12:
            raise ValueError

    except (ValueError, TypeError):
        return JsonResponse(
            {"error": "Invalid year or month."},
            status=400,
        )

    transactions = Transaction.objects.filter(
        owner=request.user,
        date__year=year,
        date__month=month,
        is_archived=False,
    )

    income = transactions.filter(
        transaction_type="income"
    ).aggregate(total=Sum("amount"))["total"] or Decimal("0.00")

    expenses = transactions.filter(
        transaction_type="expense"
    ).aggregate(total=Sum("amount"))["total"] or Decimal("0.00")

    categories = transactions.filter(
        transaction_type="expense"
    ).values("category").annotate(
        spent=Sum("amount")
    ).order_by("category")

    budgets = MonthlyBudget.objects.filter(
        owner=request.user,
        year=year,
        month=month,
    )

    budget_report = []

    for budget in budgets:
        spent = transactions.filter(
            transaction_type="expense",
            category__iexact=budget.category,
        ).aggregate(total=Sum("amount"))["total"] or Decimal("0.00")

        budget_report.append({
            "category": budget.category,
            "limit_amount": format(budget.limit_amount, ".2f"),
            "spent": format(spent, ".2f"),
            "remaining": format(budget.limit_amount - spent, ".2f"),
            "over_budget": spent > budget.limit_amount,
            "currency": budget.currency,
        })

    return JsonResponse({
        "year": year,
        "month": month,
        "currency": "INR",
        "total_income": format(income, ".2f"),
        "total_expenses": format(expenses, ".2f"),
        "net_balance": format(income - expenses, ".2f"),
        "expense_categories": [
            {
                "category": item["category"],
                "spent": format(item["spent"], ".2f"),
            }
            for item in categories
        ],
        "budgets": budget_report,
    })
