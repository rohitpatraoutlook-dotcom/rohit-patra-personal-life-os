from django.urls import path

from . import views

app_name = "finance"

urlpatterns = [
    path("transactions/", views.transactions_api, name="transactions"),
    path(
        "transactions/<int:transaction_id>/",
        views.transaction_detail_api,
        name="transaction-detail",
    ),
    path("budgets/", views.budgets_api, name="budgets"),
    path(
        "budgets/<int:budget_id>/",
        views.budget_detail_api,
        name="budget-detail",
    ),
    path("savings-goals/", views.savings_goals_api, name="savings-goals"),
    path(
        "savings-goals/<int:goal_id>/",
        views.savings_goal_detail_api,
        name="savings-goal-detail",
    ),
    path("overview/", views.finance_overview_api, name="overview"),
]
