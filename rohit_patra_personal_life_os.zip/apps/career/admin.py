from django.contrib import admin
from .models import (
    Education,
    Experience,
    Certification,
    Publication,
    OnlineProfile,
)


@admin.register(Education)
class EducationAdmin(admin.ModelAdmin):
    list_display = (
        "institution", "qualification", "owner", "is_public"
    )
    list_filter = ("is_public",)
    search_fields = ("institution", "qualification", "field_of_study")


@admin.register(Experience)
class ExperienceAdmin(admin.ModelAdmin):
    list_display = (
        "company", "job_title", "owner", "currently_working", "is_public"
    )
    list_filter = ("currently_working", "is_public")
    search_fields = ("company", "job_title", "responsibilities")


@admin.register(Certification)
class CertificationAdmin(admin.ModelAdmin):
    list_display = (
        "name", "issuing_organization", "owner", "is_public"
    )
    list_filter = ("is_public",)
    search_fields = ("name", "issuing_organization", "credential_id")


@admin.register(Publication)
class PublicationAdmin(admin.ModelAdmin):
    list_display = (
        "title", "venue", "publication_date", "owner", "is_public"
    )
    list_filter = ("status", "is_public")
    search_fields = ("title", "authors", "venue", "doi")


@admin.register(OnlineProfile)
class OnlineProfileAdmin(admin.ModelAdmin):
    list_display = ("platform", "label", "owner", "is_public")
    list_filter = ("platform", "is_public")
    search_fields = ("label", "url", "description")
