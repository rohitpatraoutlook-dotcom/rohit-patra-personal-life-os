from django.urls import path
from . import views

urlpatterns = [
    path(
        "public/<str:resource>/",
        views.public_career,
        name="public_career",
    ),
    path(
        "<str:resource>/<int:record_id>/",
        views.career_detail,
        name="career_detail",
    ),
    path(
        "<str:resource>/",
        views.career_list,
        name="career_list",
    ),
]
