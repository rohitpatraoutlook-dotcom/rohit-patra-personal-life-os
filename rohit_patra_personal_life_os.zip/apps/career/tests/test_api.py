import json

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from apps.career.models import (
    Education,
    Experience,
    Certification,
    Publication,
    OnlineProfile,
)

User = get_user_model()


class CareerAPITests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user(
            username="career_test_owner",
            password="Strong-Test-Password-123!",
        )
        self.other = User.objects.create_user(
            username="career_test_other",
            password="Strong-Test-Password-456!",
        )
        self.client.force_login(self.owner)

    def url(self, resource):
        return reverse("career_list", args=[resource])

    def detail_url(self, resource, record_id):
        return reverse("career_detail", args=[resource, record_id])

    def post_json(self, resource, data):
        return self.client.post(
            self.url(resource),
            data=json.dumps(data),
            content_type="application/json",
        )

    def test_create_education_private_by_default(self):
        response = self.post_json("education", {
            "institution": "Example University",
            "qualification": "BTech",
        })
        self.assertEqual(response.status_code, 201)
        item = Education.objects.get()
        self.assertEqual(item.owner, self.owner)
        self.assertFalse(item.is_public)

    def test_create_experience(self):
        response = self.post_json("experience", {
            "company": "Example Company",
            "job_title": "Junior Developer",
        })
        self.assertEqual(response.status_code, 201)
        self.assertEqual(Experience.objects.get().owner, self.owner)

    def test_create_certification(self):
        response = self.post_json("certifications", {
            "name": "Python Course",
            "issuing_organization": "Example Institute",
        })
        self.assertEqual(response.status_code, 201)

    def test_create_publication(self):
        response = self.post_json("publications", {
            "title": "Example Research",
            "status": "submitted",
        })
        self.assertEqual(response.status_code, 201)

    def test_create_online_profile(self):
        response = self.post_json("profiles", {
            "platform": "github",
            "url": "https://github.com/example",
        })
        self.assertEqual(response.status_code, 201)

    def test_missing_required_fields_rejected(self):
        response = self.post_json("education", {
            "institution": "Only Institution",
        })
        self.assertEqual(response.status_code, 400)

    def test_unknown_fields_rejected(self):
        response = self.post_json("education", {
            "institution": "Example",
            "qualification": "BTech",
            "owner": self.other.id,
        })
        self.assertEqual(response.status_code, 400)

    def test_invalid_public_flag_rejected(self):
        response = self.post_json("education", {
            "institution": "Example",
            "qualification": "BTech",
            "is_public": "yes",
        })
        self.assertEqual(response.status_code, 400)

    def test_list_is_owner_scoped(self):
        Education.objects.create(
            owner=self.owner,
            institution="Mine",
            qualification="BTech",
        )
        Education.objects.create(
            owner=self.other,
            institution="Other",
            qualification="MTech",
        )
        response = self.client.get(self.url("education"))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["count"], 1)

    def test_other_user_cannot_read_or_edit_education(self):
        item = Education.objects.create(
            owner=self.other,
            institution="Private",
            qualification="Degree",
        )
        url = self.detail_url("education", item.id)

        self.assertEqual(self.client.get(url).status_code, 404)

        response = self.client.patch(
            url,
            data=json.dumps({"institution": "Changed"}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 404)

        item.refresh_from_db()
        self.assertEqual(item.institution, "Private")

    def test_update_experience(self):
        item = Experience.objects.create(
            owner=self.owner,
            company="Old Company",
            job_title="Developer",
        )
        response = self.client.patch(
            self.detail_url("experience", item.id),
            data=json.dumps({"company": "New Company"}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        item.refresh_from_db()
        self.assertEqual(item.company, "New Company")

    def test_delete_certification(self):
        item = Certification.objects.create(
            owner=self.owner,
            name="Certificate",
            issuing_organization="Institute",
        )
        response = self.client.delete(
            self.detail_url("certifications", item.id)
        )
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Certification.objects.filter(id=item.id).exists())

    def test_search_publications(self):
        Publication.objects.create(
            owner=self.owner, title="Django Research"
        )
        Publication.objects.create(
            owner=self.owner, title="Other Topic"
        )
        response = self.client.get(
            self.url("publications"), {"q": "Django"}
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["count"], 1)

    def test_duplicate_online_profile_rejected(self):
        OnlineProfile.objects.create(
            owner=self.owner,
            platform="github",
            url="https://github.com/example",
        )
        response = self.post_json("profiles", {
            "platform": "github",
            "url": "https://github.com/example",
        })
        self.assertEqual(response.status_code, 409)

    def test_public_endpoint_only_returns_published_records(self):
        Education.objects.create(
            owner=self.owner,
            institution="Public College",
            qualification="BTech",
            is_public=True,
        )
        Education.objects.create(
            owner=self.owner,
            institution="Private College",
            qualification="MTech",
            is_public=False,
        )
        response = self.client.get(
            reverse("public_career", args=["education"])
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["count"], 1)

    def test_unauthenticated_private_endpoint_requires_login(self):
        self.client.logout()
        response = self.client.get(self.url("education"))
        self.assertEqual(response.status_code, 302)
