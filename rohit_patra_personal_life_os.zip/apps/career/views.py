import json
from datetime import date

from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.core.validators import URLValidator
from django.db import IntegrityError
from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.views.decorators.http import require_http_methods

from .models import (
    Education,
    Experience,
    Certification,
    Publication,
    OnlineProfile,
)


# Each resource defines its own allowed fields and serialization.
RESOURCES = {
    "education": {
        "model": Education,
        "fields": {
            "institution", "qualification", "field_of_study",
            "grade", "start_year", "end_year", "description", "is_public",
        },
        "required": {"institution", "qualification"},
        "search": ["institution", "qualification", "field_of_study"],
        "max_lengths": {
            "institution": 200,
            "qualification": 150,
            "field_of_study": 150,
            "grade": 50,
        },
    },
    "experience": {
        "model": Experience,
        "fields": {
            "company", "job_title", "employment_type", "location",
            "responsibilities", "start_date", "end_date",
            "currently_working", "is_public",
        },
        "required": {"company", "job_title"},
        "search": ["company", "job_title", "responsibilities"],
        "max_lengths": {
            "company": 200,
            "job_title": 150,
            "employment_type": 50,
            "location": 150,
        },
    },
    "certifications": {
        "model": Certification,
        "fields": {
            "name", "issuing_organization", "credential_id",
            "credential_url", "issue_date", "expiry_date",
            "does_not_expire", "description", "is_public",
        },
        "required": {"name", "issuing_organization"},
        "search": ["name", "issuing_organization", "credential_id"],
        "max_lengths": {
            "name": 200,
            "issuing_organization": 200,
            "credential_id": 150,
        },
    },
    "publications": {
        "model": Publication,
        "fields": {
            "title", "publication_type", "authors", "venue",
            "publication_date", "doi", "publication_url",
            "abstract", "status", "is_public",
        },
        "required": {"title"},
        "search": ["title", "authors", "venue", "doi"],
        "max_lengths": {
            "title": 300,
            "publication_type": 100,
            "authors": 500,
            "venue": 200,
            "doi": 200,
            "status": 50,
        },
    },
    "profiles": {
        "model": OnlineProfile,
        "fields": {
            "platform", "label", "url", "description", "is_public",
        },
        "required": {"url"},
        "search": ["label", "url", "description"],
        "max_lengths": {
            "label": 100,
            "description": 250,
        },
    },
}


def read_json(request):
    try:
        data = json.loads(request.body or b"{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None, JsonResponse({"error": "Invalid JSON."}, status=400)

    if not isinstance(data, dict):
        return None, JsonResponse(
            {"error": "JSON body must be an object."},
            status=400,
        )

    return data, None


def serialize(record):
    result = {
        "id": record.id,
        "is_public": record.is_public,
        "created_at": record.created_at.isoformat(),
        "updated_at": record.updated_at.isoformat(),
    }

    for field in record._meta.concrete_fields:
        name = field.name

        if name in ("id", "owner", "created_at", "updated_at", "is_public"):
            continue

        value = getattr(record, name)

        if isinstance(value, date):
            value = value.isoformat()

        result[name] = value

    return result


def validate_payload(resource, data, creating=False):
    spec = RESOURCES[resource]
    allowed = spec["fields"]

    unknown = set(data) - allowed
    if unknown:
        return "Unknown fields: " + ", ".join(sorted(unknown))

    for field in spec["required"]:
        if creating and (
            field not in data
            or not isinstance(data[field], str)
            or not data[field].strip()
        ):
            return f"{field} is required."

    for field, limit in spec["max_lengths"].items():
        if field in data:
            value = data[field]
            if not isinstance(value, str):
                return f"{field} must be a string."
            if len(value) > limit:
                return f"{field} cannot exceed {limit} characters."

    if "is_public" in data and type(data["is_public"]) is not bool:
        return "is_public must be true or false."

    boolean_fields = {
        "currently_working",
        "does_not_expire",
    }
    for field in boolean_fields:
        if field in data and type(data[field]) is not bool:
            return f"{field} must be true or false."

    integer_fields = {"start_year", "end_year"}
    for field in integer_fields:
        if field in data and data[field] is not None:
            value = data[field]
            if type(value) is not int or not 1900 <= value <= 2200:
                return f"{field} must be a year between 1900 and 2200."

    date_fields = {
        "start_date", "end_date", "issue_date",
        "expiry_date", "publication_date",
    }
    for field in date_fields:
        if field in data and data[field] is not None:
            value = data[field]
            if not isinstance(value, str):
                return f"{field} must use YYYY-MM-DD format."
            try:
                date.fromisoformat(value)
            except ValueError:
                return f"{field} must be a valid YYYY-MM-DD date."

    url_fields = {"credential_url", "publication_url", "url"}
    for field in url_fields:
        if field in data and data[field]:
            if not isinstance(data[field], str):
                return f"{field} must be a string."
            try:
                URLValidator()(data[field])
            except ValidationError:
                return f"{field} must be a valid URL."

    if resource == "profiles" and "platform" in data:
        valid_platforms = {
            value for value, label in OnlineProfile.Platform.choices
        }
        if data["platform"] not in valid_platforms:
            return "Invalid profile platform."

    if resource == "publications" and "status" in data:
        if data["status"] not in {
            "draft", "submitted", "under_review", "published"
        }:
            return "Invalid publication status."

    return None


def apply_payload(record, data):
    date_fields = {
        "start_date", "end_date", "issue_date",
        "expiry_date", "publication_date",
    }

    for field, value in data.items():
        if field in date_fields and isinstance(value, str):
            value = date.fromisoformat(value)

        if field in {"institution", "qualification", "company", "job_title",
                     "name", "title", "url"} and isinstance(value, str):
            value = value.strip()

        setattr(record, field, value)


@login_required
@require_http_methods(["GET", "POST"])
def career_list(request, resource):
    if resource not in RESOURCES:
        return JsonResponse({"error": "Unknown resource."}, status=404)

    spec = RESOURCES[resource]
    model = spec["model"]

    if request.method == "GET":
        queryset = model.objects.filter(owner=request.user)

        query = request.GET.get("q", "").strip()
        if query:
            condition = Q()
            for field in spec["search"]:
                condition |= Q(**{f"{field}__icontains": query})
            queryset = queryset.filter(condition)

        published = request.GET.get("public")
        if published is not None:
            if published not in ("true", "false"):
                return JsonResponse(
                    {"error": "public must be true or false."},
                    status=400,
                )
            queryset = queryset.filter(is_public=(published == "true"))

        return JsonResponse({
            "count": queryset.count(),
            "results": [serialize(item) for item in queryset],
        })

    data, error = read_json(request)
    if error:
        return error

    message = validate_payload(resource, data, creating=True)
    if message:
        return JsonResponse({"error": message}, status=400)

    record = model(owner=request.user)
    apply_payload(record, data)

    try:
        record.full_clean(exclude=["owner", "created_at", "updated_at"])
        record.save()
    except ValidationError as exc:
        return JsonResponse({"error": exc.messages}, status=400)
    except IntegrityError:
        return JsonResponse(
            {"error": "This record conflicts with an existing record."},
            status=409,
        )

    return JsonResponse(serialize(record), status=201)


@login_required
@require_http_methods(["GET", "PATCH", "DELETE"])
def career_detail(request, resource, record_id):
    if resource not in RESOURCES:
        return JsonResponse({"error": "Unknown resource."}, status=404)

    spec = RESOURCES[resource]
    model = spec["model"]

    record = get_object_or_404(
        model,
        id=record_id,
        owner=request.user,
    )

    if request.method == "GET":
        return JsonResponse(serialize(record))

    if request.method == "DELETE":
        record.delete()
        return JsonResponse({"message": "Record deleted."})

    data, error = read_json(request)
    if error:
        return error

    if not data:
        return JsonResponse(
            {"error": "Provide at least one field to update."},
            status=400,
        )

    message = validate_payload(resource, data)
    if message:
        return JsonResponse({"error": message}, status=400)

    apply_payload(record, data)

    try:
        record.full_clean(exclude=["owner", "created_at", "updated_at"])
        record.save()
    except ValidationError as exc:
        return JsonResponse({"error": exc.messages}, status=400)
    except IntegrityError:
        return JsonResponse(
            {"error": "This record conflicts with an existing record."},
            status=409,
        )

    return JsonResponse(serialize(record))


@require_http_methods(["GET"])
def public_career(request, resource):
    if resource not in RESOURCES:
        return JsonResponse({"error": "Unknown resource."}, status=404)

    model = RESOURCES[resource]["model"]
    queryset = model.objects.filter(is_public=True)

    return JsonResponse({
        "count": queryset.count(),
        "results": [serialize(item) for item in queryset],
    })
