from django.conf import settings
from django.db import models


class CareerRecord(models.Model):
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="%(class)s_records",
    )
    is_public = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class Education(CareerRecord):
    institution = models.CharField(max_length=200)
    qualification = models.CharField(max_length=150)
    field_of_study = models.CharField(max_length=150, blank=True)
    grade = models.CharField(max_length=50, blank=True)
    start_year = models.PositiveSmallIntegerField(null=True, blank=True)
    end_year = models.PositiveSmallIntegerField(null=True, blank=True)
    description = models.TextField(blank=True)

    class Meta:
        ordering = ["-end_year", "-start_year", "-updated_at"]

    def __str__(self):
        return f"{self.qualification} - {self.institution}"


class Experience(CareerRecord):
    company = models.CharField(max_length=200)
    job_title = models.CharField(max_length=150)
    employment_type = models.CharField(max_length=50, blank=True)
    location = models.CharField(max_length=150, blank=True)
    responsibilities = models.TextField(blank=True)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    currently_working = models.BooleanField(default=False)

    class Meta:
        ordering = ["-start_date", "-updated_at"]

    def __str__(self):
        return f"{self.job_title} - {self.company}"


class Certification(CareerRecord):
    name = models.CharField(max_length=200)
    issuing_organization = models.CharField(max_length=200)
    credential_id = models.CharField(max_length=150, blank=True)
    credential_url = models.URLField(blank=True)
    issue_date = models.DateField(null=True, blank=True)
    expiry_date = models.DateField(null=True, blank=True)
    does_not_expire = models.BooleanField(default=False)
    description = models.TextField(blank=True)

    class Meta:
        ordering = ["-issue_date", "-updated_at"]

    def __str__(self):
        return self.name


class Publication(CareerRecord):
    title = models.CharField(max_length=300)
    publication_type = models.CharField(max_length=100, blank=True)
    authors = models.CharField(max_length=500, blank=True)
    venue = models.CharField(max_length=200, blank=True)
    publication_date = models.DateField(null=True, blank=True)
    doi = models.CharField(max_length=200, blank=True)
    publication_url = models.URLField(blank=True)
    abstract = models.TextField(blank=True)
    status = models.CharField(max_length=50, default="published")

    class Meta:
        ordering = ["-publication_date", "-updated_at"]

    def __str__(self):
        return self.title


class OnlineProfile(CareerRecord):
    class Platform(models.TextChoices):
        LINKEDIN = "linkedin", "LinkedIn"
        GITHUB = "github", "GitHub"
        ORCID = "orcid", "ORCID"
        GOOGLE_SCHOLAR = "google_scholar", "Google Scholar"
        RESEARCHGATE = "researchgate", "ResearchGate"
        PORTFOLIO = "portfolio", "Portfolio"
        OTHER = "other", "Other"

    platform = models.CharField(
        max_length=30,
        choices=Platform.choices,
        default=Platform.OTHER,
    )
    label = models.CharField(max_length=100, blank=True)
    url = models.URLField()
    description = models.CharField(max_length=250, blank=True)

    class Meta:
        ordering = ["platform", "label"]
        constraints = [
            models.UniqueConstraint(
                fields=["owner", "platform", "url"],
                name="unique_career_profile_per_owner",
            )
        ]

    def __str__(self):
        return self.label or self.get_platform_display()
