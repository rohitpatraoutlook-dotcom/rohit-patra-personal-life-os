from django.conf import settings
from django.db import models


class Note(models.Model):
    class EntryType(models.TextChoices):
        NOTE = "note", "Note"
        JOURNAL = "journal", "Journal"

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="personal_notes",
    )

    entry_type = models.CharField(
        max_length=10,
        choices=EntryType.choices,
        default=EntryType.NOTE,
    )

    title = models.CharField(max_length=200)
    body = models.TextField()
    category = models.CharField(max_length=100, blank=True)
    tags = models.CharField(max_length=500, blank=True)

    is_pinned = models.BooleanField(default=False)
    is_archived = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-is_pinned", "-updated_at"]
        indexes = [
            models.Index(fields=["owner", "entry_type"]),
            models.Index(fields=["owner", "is_archived"]),
        ]

    def __str__(self):
        return self.title
