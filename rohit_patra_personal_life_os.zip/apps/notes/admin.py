from django.contrib import admin
from .models import Note


@admin.register(Note)
class NoteAdmin(admin.ModelAdmin):
    list_display = (
        "title",
        "owner",
        "entry_type",
        "is_pinned",
        "is_archived",
        "updated_at",
    )
    list_filter = ("entry_type", "is_pinned", "is_archived")
    search_fields = ("title", "body", "category", "tags")
    readonly_fields = ("created_at", "updated_at")
