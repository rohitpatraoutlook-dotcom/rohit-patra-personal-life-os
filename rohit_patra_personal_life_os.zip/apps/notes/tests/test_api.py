import json

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from apps.notes.models import Note

User = get_user_model()


class NotesAPITests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user(
            username="notes_owner",
            password="Strong-Test-Password-123!",
        )
        self.other = User.objects.create_user(
            username="notes_other",
            password="Strong-Test-Password-456!",
        )
        self.client.force_login(self.owner)
        self.list_url = reverse("notes_list")

    def json_request(self, method, url, data=None):
        return getattr(self.client, method)(
            url,
            data=json.dumps(data) if data is not None else "{}",
            content_type="application/json",
        )

    def test_create_note(self):
        response = self.json_request("post", self.list_url, {
            "title": "My plan",
            "body": "Learn Django",
        })
        self.assertEqual(response.status_code, 201)
        self.assertEqual(Note.objects.count(), 1)
        self.assertEqual(Note.objects.get().owner, self.owner)

    def test_create_journal_entry(self):
        response = self.json_request("post", self.list_url, {
            "entry_type": "journal",
            "title": "Today",
            "body": "Today I learned testing.",
        })
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json()["entry_type"], "journal")

    def test_title_required(self):
        response = self.json_request("post", self.list_url, {
            "body": "Missing title",
        })
        self.assertEqual(response.status_code, 400)

    def test_invalid_entry_type_rejected(self):
        response = self.json_request("post", self.list_url, {
            "title": "Invalid",
            "body": "Body",
            "entry_type": "secret",
        })
        self.assertEqual(response.status_code, 400)

    def test_list_only_shows_owner_notes(self):
        Note.objects.create(owner=self.owner, title="Mine", body="Private")
        Note.objects.create(owner=self.other, title="Other", body="Hidden")

        response = self.client.get(self.list_url)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["count"], 1)
        self.assertEqual(response.json()["results"][0]["title"], "Mine")

    def test_search_notes(self):
        Note.objects.create(
            owner=self.owner, title="Django project", body="API work"
        )
        Note.objects.create(
            owner=self.owner, title="Shopping", body="Buy milk"
        )
        response = self.client.get(self.list_url, {"q": "Django"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["count"], 1)

    def test_filter_pinned_notes(self):
        Note.objects.create(
            owner=self.owner, title="Pinned", body="Important",
            is_pinned=True,
        )
        Note.objects.create(
            owner=self.owner, title="Normal", body="Other",
        )
        response = self.client.get(self.list_url, {"pinned": "true"})
        self.assertEqual(response.json()["count"], 1)

    def test_update_note(self):
        note = Note.objects.create(
            owner=self.owner, title="Old", body="Old body"
        )
        response = self.json_request(
            "patch",
            reverse("note_detail", args=[note.id]),
            {"title": "Updated"},
        )
        self.assertEqual(response.status_code, 200)
        note.refresh_from_db()
        self.assertEqual(note.title, "Updated")

    def test_pin_and_archive_note(self):
        note = Note.objects.create(
            owner=self.owner, title="Item", body="Body"
        )
        response = self.json_request(
            "patch",
            reverse("note_detail", args=[note.id]),
            {"is_pinned": True, "is_archived": True},
        )
        self.assertEqual(response.status_code, 200)
        note.refresh_from_db()
        self.assertTrue(note.is_pinned)
        self.assertTrue(note.is_archived)

    def test_delete_note(self):
        note = Note.objects.create(
            owner=self.owner, title="Delete me", body="Body"
        )
        response = self.client.delete(
            reverse("note_detail", args=[note.id])
        )
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Note.objects.filter(id=note.id).exists())

    def test_cannot_access_other_users_note(self):
        note = Note.objects.create(
            owner=self.other, title="Private", body="Secret"
        )
        url = reverse("note_detail", args=[note.id])

        self.assertEqual(self.client.get(url).status_code, 404)
        self.assertEqual(
            self.json_request("patch", url, {"title": "Stolen"}).status_code,
            404,
        )
        self.assertEqual(self.client.delete(url).status_code, 404)

        note.refresh_from_db()
        self.assertEqual(note.title, "Private")

    def test_unauthenticated_access_rejected(self):
        self.client.logout()
        self.assertEqual(self.client.get(self.list_url).status_code, 302)

    def test_unknown_fields_rejected(self):
        response = self.json_request("post", self.list_url, {
            "title": "Test",
            "body": "Body",
            "owner": self.other.id,
        })
        self.assertEqual(response.status_code, 400)

    def test_boolean_fields_require_boolean_values(self):
        response = self.json_request("post", self.list_url, {
            "title": "Test",
            "body": "Body",
            "is_pinned": "yes",
        })
        self.assertEqual(response.status_code, 400)
