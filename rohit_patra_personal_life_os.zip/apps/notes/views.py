import json

from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.views.decorators.http import require_http_methods

from .models import Note


def parse_body(request):
    try:
        data = json.loads(request.body or b"{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None, JsonResponse(
            {"error": "Invalid JSON body."}, status=400
        )

    if not isinstance(data, dict):
        return None, JsonResponse(
            {"error": "JSON body must be an object."}, status=400
        )

    return data, None


def note_data(note):
    return {
        "id": note.id,
        "entry_type": note.entry_type,
        "title": note.title,
        "body": note.body,
        "category": note.category,
        "tags": note.tags,
        "is_pinned": note.is_pinned,
        "is_archived": note.is_archived,
        "created_at": note.created_at.isoformat(),
        "updated_at": note.updated_at.isoformat(),
    }


def validate_fields(data, creating=False):
    allowed = {
        "entry_type",
        "title",
        "body",
        "category",
        "tags",
        "is_pinned",
        "is_archived",
    }

    unknown = set(data) - allowed
    if unknown:
        return f"Unknown fields: {', '.join(sorted(unknown))}"

    if creating and not data.get("title", "").strip():
        return "Title is required."

    if creating and "body" not in data:
        return "Body is required."

    if "title" in data:
        if not isinstance(data["title"], str) or not data["title"].strip():
            return "Title must be a non-empty string."
        if len(data["title"].strip()) > 200:
            return "Title cannot exceed 200 characters."

    if "body" in data and not isinstance(data["body"], str):
        return "Body must be a string."

    if "entry_type" in data:
        if data["entry_type"] not in Note.EntryType.values:
            return "entry_type must be 'note' or 'journal'."

    for field, limit in (("category", 100), ("tags", 500)):
        if field in data:
            value = data[field]
            if not isinstance(value, str):
                return f"{field} must be a string."
            if len(value) > limit:
                return f"{field} cannot exceed {limit} characters."

    for field in ("is_pinned", "is_archived"):
        if field in data and type(data[field]) is not bool:
            return f"{field} must be true or false."

    return None


def apply_fields(note, data):
    for field in (
        "entry_type",
        "title",
        "body",
        "category",
        "tags",
        "is_pinned",
        "is_archived",
    ):
        if field in data:
            value = data[field]
            if field == "title":
                value = value.strip()
            setattr(note, field, value)


@login_required
@require_http_methods(["GET", "POST"])
def notes_list(request):
    if request.method == "GET":
        # The queryset is always restricted to the logged-in owner.
        queryset = Note.objects.filter(owner=request.user)

        search = request.GET.get("q", "").strip()
        if search:
            from django.db.models import Q
            queryset = queryset.filter(
                Q(title__icontains=search)
                | Q(body__icontains=search)
                | Q(category__icontains=search)
                | Q(tags__icontains=search)
            )

        entry_type = request.GET.get("entry_type")
        if entry_type:
            if entry_type not in Note.EntryType.values:
                return JsonResponse(
                    {"error": "Invalid entry_type."}, status=400
                )
            queryset = queryset.filter(entry_type=entry_type)

        archived = request.GET.get("archived")
        if archived is not None:
            if archived not in ("true", "false"):
                return JsonResponse(
                    {"error": "archived must be true or false."},
                    status=400,
                )
            queryset = queryset.filter(
                is_archived=(archived == "true")
            )

        pinned = request.GET.get("pinned")
        if pinned is not None:
            if pinned not in ("true", "false"):
                return JsonResponse(
                    {"error": "pinned must be true or false."},
                    status=400,
                )
            queryset = queryset.filter(is_pinned=(pinned == "true"))

        return JsonResponse({
            "results": [note_data(note) for note in queryset],
            "count": queryset.count(),
        })

    data, error = parse_body(request)
    if error:
        return error

    message = validate_fields(data, creating=True)
    if message:
        return JsonResponse({"error": message}, status=400)

    note = Note(owner=request.user)
    apply_fields(note, data)
    note.save()

    return JsonResponse(note_data(note), status=201)


@login_required
@require_http_methods(["GET", "PATCH", "DELETE"])
def note_detail(request, note_id):
    # Users cannot read, modify, or delete another user's note.
    note = get_object_or_404(Note, id=note_id, owner=request.user)

    if request.method == "GET":
        return JsonResponse(note_data(note))

    if request.method == "DELETE":
        note.delete()
        return JsonResponse({"message": "Note deleted successfully."})

    data, error = parse_body(request)
    if error:
        return error

    message = validate_fields(data)
    if message:
        return JsonResponse({"error": message}, status=400)

    if not data:
        return JsonResponse(
            {"error": "At least one field is required."}, status=400
        )

    apply_fields(note, data)
    note.save()

    return JsonResponse(note_data(note))
