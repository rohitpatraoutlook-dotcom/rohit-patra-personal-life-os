import json
from datetime import date

from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.views.decorators.http import require_http_methods

from .models import Task


def task_to_dict(task):
    return {
        "id": task.id,
        "title": task.title,
        "description": task.description,
        "status": task.status,
        "priority": task.priority,
        "due_date": task.due_date.isoformat() if task.due_date else None,
        "created_at": task.created_at.isoformat(),
        "updated_at": task.updated_at.isoformat(),
    }


def parse_json(request):
    try:
        data = json.loads(request.body or b"{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None, JsonResponse(
            {"error": "Invalid JSON body."},
            status=400,
        )

    if not isinstance(data, dict):
        return None, JsonResponse(
            {"error": "JSON body must be an object."},
            status=400,
        )

    return data, None


def validate_fields(data, creating=False):
    allowed = {"title", "description", "priority", "status", "due_date"}

    unknown = set(data) - allowed
    if unknown:
        return "Unsupported fields: " + ", ".join(sorted(unknown))

    if creating and "title" not in data:
        return "Title is required."

    if "title" in data:
        title = data["title"]
        if not isinstance(title, str) or not title.strip():
            return "Title must be a non-empty string."
        if len(title.strip()) > 200:
            return "Title cannot exceed 200 characters."

    if "description" in data and not isinstance(data["description"], str):
        return "Description must be a string."

    if "priority" in data and data["priority"] not in Task.Priority.values:
        return "Priority must be low, normal, or high."

    if "status" in data and data["status"] not in Task.Status.values:
        return "Status must be open, in_progress, or completed."

    if "due_date" in data and data["due_date"] is not None:
        if not isinstance(data["due_date"], str):
            return "Due date must be YYYY-MM-DD or null."
        try:
            date.fromisoformat(data["due_date"])
        except ValueError:
            return "Due date must be a valid YYYY-MM-DD date."

    return None


def apply_fields(task, data):
    for field in ("title", "description", "priority", "status"):
        if field in data:
            value = data[field]
            setattr(task, field, value.strip() if field == "title" else value)

    if "due_date" in data:
        task.due_date = (
            date.fromisoformat(data["due_date"])
            if data["due_date"] is not None
            else None
        )


@login_required
@require_http_methods(["GET", "POST"])
def task_collection(request):
    if request.method == "GET":
        tasks = Task.objects.filter(owner=request.user)
        return JsonResponse({
            "count": tasks.count(),
            "results": [task_to_dict(task) for task in tasks],
        })

    data, error_response = parse_json(request)
    if error_response:
        return error_response

    error = validate_fields(data, creating=True)
    if error:
        return JsonResponse({"error": error}, status=400)

    task = Task(owner=request.user)
    apply_fields(task, data)
    task.save()

    return JsonResponse(task_to_dict(task), status=201)


@login_required
@require_http_methods(["GET", "PUT", "PATCH", "DELETE"])
def task_detail(request, task_id):
    # Restrict the lookup to the logged-in owner's records.
    task = get_object_or_404(
        Task,
        id=task_id,
        owner=request.user,
    )

    if request.method == "GET":
        return JsonResponse(task_to_dict(task))

    if request.method == "DELETE":
        task.delete()
        return JsonResponse({"message": "Task deleted."}, status=200)

    data, error_response = parse_json(request)
    if error_response:
        return error_response

    error = validate_fields(data)
    if error:
        return JsonResponse({"error": error}, status=400)

    apply_fields(task, data)
    task.save()

    return JsonResponse(task_to_dict(task))


@login_required
@require_http_methods(["POST"])
def complete_task(request, task_id):
    task = get_object_or_404(
        Task,
        id=task_id,
        owner=request.user,
    )

    task.status = Task.Status.COMPLETED
    task.save(update_fields=["status", "updated_at"])

    return JsonResponse(task_to_dict(task))
