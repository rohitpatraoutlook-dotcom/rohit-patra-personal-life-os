from django.urls import path

from . import views

urlpatterns = [
    path("tasks/", views.task_collection, name="task_collection"),
    path("tasks/<int:task_id>/", views.task_detail, name="task_detail"),
    path(
        "tasks/<int:task_id>/complete/",
        views.complete_task,
        name="complete_task",
    ),
]
