import json

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from apps.tasks.models import Task


User = get_user_model()


class TaskAPITests(TestCase):

    @classmethod
    def setUpTestData(cls):
        cls.owner = User.objects.create_user(
            username="task_owner",
            password="Testing-Password-123!",
        )

        cls.other_user = User.objects.create_user(
            username="other_owner",
            password="Testing-Password-456!",
        )

    def setUp(self):
        self.client.force_login(self.owner)
        self.collection_url = reverse("task_collection")

    def json_post(self, url, payload):
        return self.client.post(
            url,
            data=json.dumps(payload),
            content_type="application/json",
        )

    def create_task(self, **overrides):
        data = {
            "title": "Complete project",
            "description": "Finish backend implementation",
            "priority": "high",
            "due_date": "2026-12-31",
        }
        data.update(overrides)
        return self.json_post(self.collection_url, data)

    def test_create_task(self):
        response = self.create_task()

        self.assertEqual(response.status_code, 201)
        self.assertEqual(Task.objects.count(), 1)

        task = Task.objects.get()
        self.assertEqual(task.owner, self.owner)
        self.assertEqual(task.title, "Complete project")
        self.assertEqual(task.priority, "high")

    def test_list_only_returns_owners_tasks(self):
        Task.objects.create(owner=self.owner, title="My task")
        Task.objects.create(owner=self.other_user, title="Private other task")

        response = self.client.get(self.collection_url)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["count"], 1)
        self.assertEqual(
            response.json()["results"][0]["title"],
            "My task",
        )

    def test_update_task(self):
        task = Task.objects.create(owner=self.owner, title="Old title")

        response = self.client.patch(
            reverse("task_detail", args=[task.id]),
            data=json.dumps({"title": "Updated title", "priority": "low"}),
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 200)
        task.refresh_from_db()
        self.assertEqual(task.title, "Updated title")
        self.assertEqual(task.priority, "low")

    def test_complete_task(self):
        task = Task.objects.create(owner=self.owner, title="Finish task")

        response = self.client.post(
            reverse("complete_task", args=[task.id])
        )

        self.assertEqual(response.status_code, 200)
        task.refresh_from_db()
        self.assertEqual(task.status, Task.Status.COMPLETED)

    def test_delete_task(self):
        task = Task.objects.create(owner=self.owner, title="Delete me")

        response = self.client.delete(
            reverse("task_detail", args=[task.id])
        )

        self.assertEqual(response.status_code, 200)
        self.assertFalse(Task.objects.filter(id=task.id).exists())

    def test_other_user_cannot_read_task(self):
        task = Task.objects.create(
            owner=self.other_user,
            title="Private task",
        )

        response = self.client.get(
            reverse("task_detail", args=[task.id])
        )

        self.assertEqual(response.status_code, 404)

    def test_other_user_cannot_delete_task(self):
        task = Task.objects.create(
            owner=self.other_user,
            title="Protected task",
        )

        response = self.client.delete(
            reverse("task_detail", args=[task.id])
        )

        self.assertEqual(response.status_code, 404)
        self.assertTrue(Task.objects.filter(id=task.id).exists())

    def test_invalid_title_is_rejected(self):
        response = self.json_post(
            self.collection_url,
            {"title": "   "},
        )

        self.assertEqual(response.status_code, 400)
        self.assertEqual(Task.objects.count(), 0)

    def test_invalid_priority_is_rejected(self):
        response = self.create_task(priority="urgent")

        self.assertEqual(response.status_code, 400)
        self.assertEqual(Task.objects.count(), 0)

    def test_malformed_json_is_rejected(self):
        response = self.client.post(
            self.collection_url,
            data="{invalid json",
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 400)

    def test_unauthenticated_user_cannot_create_task(self):
        self.client.logout()

        response = self.json_post(
            self.collection_url,
            {"title": "Should not be created"},
        )

        self.assertEqual(response.status_code, 302)
        self.assertEqual(Task.objects.count(), 0)
