import json
from datetime import date

from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.views.decorators.http import require_http_methods

from .models import Goal, Milestone


def parse_body(request):
    try:
        data = json.loads(request.body or b"{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None, JsonResponse(
            {"error": "Invalid JSON body."},
            status=400,
        )

    if not isinstance(data, dict):
        return None, JsonResponse(
            {"error": "JSON body must be an object."},
            status=400,
        )

    return data, None


def validate_fields(data, creating=False, milestone=False):
    allowed = {"title", "description", "target_date"}

    if not milestone:
        allowed.update({"status", "progress"})

    unknown = set(data) - allowed
    if unknown:
        return "Unsupported fields: " + ", ".join(sorted(unknown))

    if creating and "title" not in data:
        return "Title is required."

    if "title" in data:
        title = data["title"]
        if not isinstance(title, str) or not title.strip():
            return "Title must be a non-empty string."
        if len(title.strip()) > 200:
            return "Title cannot exceed 200 characters."

    if "description" in data:
        if not isinstance(data["description"], str):
            return "Description must be a string."

    if "target_date" in data and data["target_date"] is not None:
        if not isinstance(data["target_date"], str):
            return "Target date must be YYYY-MM-DD or null."
        try:
            date.fromisoformat(data["target_date"])
        except ValueError:
            return "Target date must be a valid YYYY-MM-DD date."

    if not milestone:
        if "status" in data and data["status"] not in Goal.Status.values:
            return "Invalid goal status."

        if "progress" in data:
            progress = data["progress"]
            if type(progress) is not int or not 0 <= progress <= 100:
                return "Progress must be an integer from 0 to 100."

    return None


def apply_fields(obj, data):
    for field in ("title", "description", "status", "progress"):
        if field in data:
            value = data[field]
            setattr(obj, field, value.strip() if field == "title" else value)

    if "target_date" in data:
        obj.target_date = (
            date.fromisoformat(data["target_date"])
            if data["target_date"] is not None
            else None
        )


def milestone_data(milestone):
    return {
        "id": milestone.id,
        "goal_id": milestone.goal_id,
        "title": milestone.title,
        "description": milestone.description,
        "is_completed": milestone.is_completed,
        "target_date": (
            milestone.target_date.isoformat()
            if milestone.target_date else None
        ),
        "created_at": milestone.created_at.isoformat(),
    }


def goal_data(goal):
    return {
        "id": goal.id,
        "title": goal.title,
        "description": goal.description,
        "status": goal.status,
        "progress": goal.progress,
        "target_date": (
            goal.target_date.isoformat()
            if goal.target_date else None
        ),
        "milestone_count": goal.milestones.count(),
        "completed_milestones": goal.milestones.filter(
            is_completed=True
        ).count(),
        "created_at": goal.created_at.isoformat(),
        "updated_at": goal.updated_at.isoformat(),
    }


@login_required
@require_http_methods(["GET", "POST"])
def goal_collection(request):
    if request.method == "GET":
        goals = Goal.objects.filter(owner=request.user)

        return JsonResponse({
            "count": goals.count(),
            "results": [goal_data(goal) for goal in goals],
        })

    data, error = parse_body(request)
    if error:
        return error

    message = validate_fields(data, creating=True)
    if message:
        return JsonResponse({"error": message}, status=400)

    goal = Goal(owner=request.user)
    apply_fields(goal, data)
    goal.save()

    return JsonResponse(goal_data(goal), status=201)


@login_required
@require_http_methods(["GET", "PUT", "PATCH", "DELETE"])
def goal_detail(request, goal_id):
    goal = get_object_or_404(
        Goal,
        id=goal_id,
        owner=request.user,
    )

    if request.method == "GET":
        return JsonResponse({
            **goal_data(goal),
            "milestones": [
                milestone_data(item)
                for item in goal.milestones.all()
            ],
        })

    if request.method == "DELETE":
        goal.delete()
        return JsonResponse({"message": "Goal deleted."})

    data, error = parse_body(request)
    if error:
        return error

    message = validate_fields(data)
    if message:
        return JsonResponse({"error": message}, status=400)

    apply_fields(goal, data)
    goal.save()

    return JsonResponse(goal_data(goal))


@login_required
@require_http_methods(["GET", "POST"])
def milestone_collection(request, goal_id):
    goal = get_object_or_404(
        Goal,
        id=goal_id,
        owner=request.user,
    )

    if request.method == "GET":
        milestones = goal.milestones.all()

        return JsonResponse({
            "count": milestones.count(),
            "results": [
                milestone_data(item) for item in milestones
            ],
        })

    data, error = parse_body(request)
    if error:
        return error

    message = validate_fields(data, creating=True, milestone=True)
    if message:
        return JsonResponse({"error": message}, status=400)

    milestone = Milestone(goal=goal)
    apply_fields(milestone, data)
    milestone.save()

    return JsonResponse(milestone_data(milestone), status=201)


@login_required
@require_http_methods(["PATCH", "DELETE"])
def milestone_detail(request, goal_id, milestone_id):
    goal = get_object_or_404(
        Goal,
        id=goal_id,
        owner=request.user,
    )

    milestone = get_object_or_404(
        Milestone,
        id=milestone_id,
        goal=goal,
    )

    if request.method == "DELETE":
        milestone.delete()
        return JsonResponse({"message": "Milestone deleted."})

    data, error = parse_body(request)
    if error:
        return error

    allowed = {"title", "description", "target_date", "is_completed"}
    unknown = set(data) - allowed

    if unknown:
        return JsonResponse(
            {"error": "Unsupported milestone fields."},
            status=400,
        )

    if "title" in data:
        title = data["title"]
        if not isinstance(title, str) or not title.strip():
            return JsonResponse(
                {"error": "Title must be a non-empty string."},
                status=400,
            )
        if len(title.strip()) > 200:
            return JsonResponse(
                {"error": "Title cannot exceed 200 characters."},
                status=400,
            )

    if "description" in data and not isinstance(data["description"], str):
        return JsonResponse(
            {"error": "Description must be a string."},
            status=400,
        )

    if "target_date" in data and data["target_date"] is not None:
        if not isinstance(data["target_date"], str):
            return JsonResponse(
                {"error": "Target date must be YYYY-MM-DD or null."},
                status=400,
            )
        try:
            date.fromisoformat(data["target_date"])
        except ValueError:
            return JsonResponse(
                {"error": "Target date must be a valid YYYY-MM-DD date."},
                status=400,
            )

    if "is_completed" in data:
        if type(data["is_completed"]) is not bool:
            return JsonResponse(
                {"error": "is_completed must be true or false."},
                status=400,
            )
        milestone.is_completed = data["is_completed"]

    apply_fields(milestone, {
        key: value
        for key, value in data.items()
        if key in {"title", "description", "target_date"}
    })

    milestone.save()
    return JsonResponse(milestone_data(milestone))
