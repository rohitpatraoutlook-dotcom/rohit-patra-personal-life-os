from django.urls import path

from . import views

urlpatterns = [
    path("goals/", views.goal_collection, name="goal_collection"),
    path("goals/<int:goal_id>/", views.goal_detail, name="goal_detail"),

    path(
        "goals/<int:goal_id>/milestones/",
        views.milestone_collection,
        name="milestone_collection",
    ),

    path(
        "goals/<int:goal_id>/milestones/<int:milestone_id>/",
        views.milestone_detail,
        name="milestone_detail",
    ),
]
