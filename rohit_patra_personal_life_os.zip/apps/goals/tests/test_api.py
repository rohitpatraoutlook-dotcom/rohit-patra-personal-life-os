import json

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from apps.goals.models import Goal, Milestone


User = get_user_model()


class GoalAPITests(TestCase):

    @classmethod
    def setUpTestData(cls):
        cls.owner = User.objects.create_user(
            username="goal_owner",
            password="Goal-Testing-123!",
        )
        cls.other_user = User.objects.create_user(
            username="other_goal_owner",
            password="Goal-Testing-456!",
        )

    def setUp(self):
        self.client.force_login(self.owner)
        self.collection_url = reverse("goal_collection")

    def post_json(self, url, data):
        return self.client.post(
            url,
            data=json.dumps(data),
            content_type="application/json",
        )

    def create_goal(self, **overrides):
        data = {
            "title": "Learn Django",
            "description": "Build a personal application",
            "target_date": "2026-12-31",
            "progress": 20,
        }
        data.update(overrides)
        return self.post_json(self.collection_url, data)

    def test_create_goal(self):
        response = self.create_goal()

        self.assertEqual(response.status_code, 201)
        self.assertEqual(Goal.objects.count(), 1)
        self.assertEqual(Goal.objects.get().owner, self.owner)

    def test_list_only_owners_goals(self):
        Goal.objects.create(owner=self.owner, title="My goal")
        Goal.objects.create(owner=self.other_user, title="Private goal")

        response = self.client.get(self.collection_url)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["count"], 1)

    def test_update_goal(self):
        goal = Goal.objects.create(
            owner=self.owner,
            title="Old title",
        )

        response = self.client.patch(
            reverse("goal_detail", args=[goal.id]),
            data=json.dumps({
                "title": "New title",
                "progress": 65,
            }),
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 200)
        goal.refresh_from_db()
        self.assertEqual(goal.title, "New title")
        self.assertEqual(goal.progress, 65)

    def test_delete_goal(self):
        goal = Goal.objects.create(owner=self.owner, title="Delete me")

        response = self.client.delete(
            reverse("goal_detail", args=[goal.id])
        )

        self.assertEqual(response.status_code, 200)
        self.assertFalse(Goal.objects.filter(id=goal.id).exists())

    def test_invalid_progress_rejected(self):
        response = self.create_goal(progress=101)

        self.assertEqual(response.status_code, 400)
        self.assertEqual(Goal.objects.count(), 0)

    def test_other_user_cannot_access_goal(self):
        goal = Goal.objects.create(
            owner=self.other_user,
            title="Private goal",
        )

        response = self.client.get(
            reverse("goal_detail", args=[goal.id])
        )

        self.assertEqual(response.status_code, 404)

    def test_create_milestone(self):
        goal = Goal.objects.create(owner=self.owner, title="Learn Django")

        response = self.post_json(
            reverse("milestone_collection", args=[goal.id]),
            {"title": "Finish models"},
        )

        self.assertEqual(response.status_code, 201)
        self.assertEqual(goal.milestones.count(), 1)

    def test_complete_milestone(self):
        goal = Goal.objects.create(owner=self.owner, title="Learn Django")
        milestone = Milestone.objects.create(
            goal=goal,
            title="Build API",
        )

        response = self.client.patch(
            reverse(
                "milestone_detail",
                args=[goal.id, milestone.id],
            ),
            data=json.dumps({"is_completed": True}),
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 200)
        milestone.refresh_from_db()
        self.assertTrue(milestone.is_completed)

    def test_other_user_cannot_create_milestone_in_foreign_goal(self):
        foreign_goal = Goal.objects.create(
            owner=self.other_user,
            title="Another person's goal",
        )

        response = self.post_json(
            reverse("milestone_collection", args=[foreign_goal.id]),
            {"title": "Unauthorized milestone"},
        )

        self.assertEqual(response.status_code, 404)
        self.assertEqual(foreign_goal.milestones.count(), 0)

    def test_unauthenticated_user_cannot_list_goals(self):
        self.client.logout()

        response = self.client.get(self.collection_url)

        self.assertEqual(response.status_code, 302)
