from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import User


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = (
        "username",
        "email",
        "display_name",
        "is_staff",
        "is_active",
    )

    search_fields = (
        "username",
        "email",
        "display_name",
    )

    fieldsets = UserAdmin.fieldsets + (
        (
            "Personal Life OS",
            {
                "fields": (
                    "display_name",
                    "created_at",
                )
            },
        ),
    )

    readonly_fields = ("created_at",)
