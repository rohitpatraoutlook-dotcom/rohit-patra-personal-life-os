from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse


User = get_user_model()


class AuthenticationTests(TestCase):

    @classmethod
    def setUpTestData(cls):
        cls.owner = User.objects.create_superuser(
            username="test_owner",
            email="owner-test@example.com",
            password="Test-Only-Password-987!",
            display_name="Test Owner",
        )

    def test_login_page_loads(self):
        response = self.client.get(reverse("login"))
        self.assertEqual(response.status_code, 200)

    def test_dashboard_requires_authentication(self):
        response = self.client.get(reverse("dashboard"))

        self.assertEqual(response.status_code, 302)
        self.assertIn("/login/", response.url)

    def test_owner_can_login(self):
        result = self.client.login(
            username="test_owner",
            password="Test-Only-Password-987!",
        )

        self.assertTrue(result)

    def test_authenticated_owner_can_access_dashboard(self):
        self.client.force_login(self.owner)

        response = self.client.get(reverse("dashboard"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "PRIVATE WORKSPACE")

    def test_invalid_password_is_rejected(self):
        result = self.client.login(
            username="test_owner",
            password="Wrong-Password-123!",
        )

        self.assertFalse(result)

    def test_owner_account_is_superuser(self):
        self.assertTrue(self.owner.is_superuser)
        self.assertTrue(self.owner.is_staff)
        self.assertTrue(self.owner.is_active)
