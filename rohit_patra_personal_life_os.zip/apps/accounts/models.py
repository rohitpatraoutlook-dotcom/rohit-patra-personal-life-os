from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """
    Custom account for the owner of Personal Life OS.
    Public registration will not be enabled.
    """

    display_name = models.CharField(
        max_length=100,
        default="Rohit Patra"
    )

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.display_name or self.username
