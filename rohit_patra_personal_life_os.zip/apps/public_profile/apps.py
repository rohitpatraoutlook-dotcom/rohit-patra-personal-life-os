from django.apps import AppConfig


class PublicProfileConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.public_profile"
