from django.contrib import admin
from .models import Resume, CoverLetter, JobApplication


@admin.register(Resume)
class ResumeAdmin(admin.ModelAdmin):
    list_display = (
        "title", "owner", "target_role", "version",
        "is_default", "is_archived",
    )
    list_filter = ("is_default", "is_archived")
    search_fields = ("title", "target_role", "owner__username")


@admin.register(CoverLetter)
class CoverLetterAdmin(admin.ModelAdmin):
    list_display = (
        "title", "company", "target_role", "owner", "is_archived",
    )
    list_filter = ("is_archived",)
    search_fields = ("title", "company", "target_role", "content")


@admin.register(JobApplication)
class JobApplicationAdmin(admin.ModelAdmin):
    list_display = (
        "company", "job_title", "owner", "status",
        "application_date", "follow_up_date",
    )
    list_filter = ("status", "is_archived", "employment_type")
    search_fields = ("company", "job_title", "location")
    date_hierarchy = "created_at"
