import json
from datetime import date, datetime

from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.core.validators import URLValidator
from django.db import IntegrityError
from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.views.decorators.http import require_http_methods

from .models import Resume, CoverLetter, JobApplication


RESOURCE_CONFIG = {
    "resumes": {
        "model": Resume,
        "fields": {
            "title", "target_role", "summary", "version",
            "is_default", "is_archived",
        },
        "required": {"title"},
        "search": ["title", "target_role", "summary"],
        "strings": {
            "title": 200,
            "target_role": 150,
        },
    },
    "cover-letters": {
        "model": CoverLetter,
        "fields": {
            "title", "company", "target_role", "content", "is_archived",
        },
        "required": {"title", "content"},
        "search": ["title", "company", "target_role", "content"],
        "strings": {
            "title": 200,
            "company": 200,
            "target_role": 150,
        },
    },
    "applications": {
        "model": JobApplication,
        "fields": {
            "company", "job_title", "job_url", "location",
            "employment_type", "status", "application_date",
            "interview_date", "follow_up_date", "salary_min",
            "salary_max", "notes", "next_action", "is_archived",
            "resume_id", "cover_letter_id",
        },
        "required": {"company", "job_title"},
        "search": ["company", "job_title", "location", "notes"],
        "strings": {
            "company": 200,
            "job_title": 200,
            "location": 150,
            "employment_type": 50,
            "next_action": 250,
        },
    },
}


def parse_json(request):
    try:
        data = json.loads(request.body or b"{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None, JsonResponse({"error": "Invalid JSON."}, status=400)

    if not isinstance(data, dict):
        return None, JsonResponse(
            {"error": "JSON body must be an object."}, status=400
        )

    return data, None


def serialize(record, resource):
    result = {
        "id": record.id,
        "created_at": record.created_at.isoformat(),
        "updated_at": record.updated_at.isoformat(),
    }

    for field in record._meta.concrete_fields:
        name = field.name

        if name in {"id", "owner", "created_at", "updated_at"}:
            continue

        value = getattr(record, name)

        if isinstance(value, (date, datetime)):
            value = value.isoformat()

        result[name] = value

    if resource == "applications":
        result["resume_id"] = record.resume_id
        result["cover_letter_id"] = record.cover_letter_id

    return result


def validate_payload(resource, data, creating=False):
    config = RESOURCE_CONFIG[resource]

    unknown = set(data) - config["fields"]
    if unknown:
        return "Unknown fields: " + ", ".join(sorted(unknown))

    for field in config["required"]:
        if creating and (
            not isinstance(data.get(field), str)
            or not data[field].strip()
        ):
            return f"{field} is required."

    for field, limit in config["strings"].items():
        if field in data:
            value = data[field]
            if not isinstance(value, str):
                return f"{field} must be a string."
            if len(value) > limit:
                return f"{field} cannot exceed {limit} characters."

    text_fields = {
        "summary", "content", "notes",
    }
    for field in text_fields:
        if field in data and not isinstance(data[field], str):
            return f"{field} must be a string."

    boolean_fields = {"is_default", "is_archived"}
    for field in boolean_fields:
        if field in data and type(data[field]) is not bool:
            return f"{field} must be true or false."

    if "version" in data:
        value = data["version"]
        if type(value) is not int or not 1 <= value <= 10000:
            return "version must be a positive integer."

    if resource == "applications":
        if "status" in data:
            if data["status"] not in JobApplication.Status.values:
                return "Invalid application status."

        for field in ("salary_min", "salary_max"):
            if field in data and data[field] is not None:
                value = data[field]
                if type(value) is not int or not 0 <= value <= 100000000:
                    return f"{field} must be a non-negative integer."

        for field in ("resume_id", "cover_letter_id"):
            if field in data and data[field] is not None:
                if type(data[field]) is not int or data[field] <= 0:
                    return f"{field} must be a positive integer or null."

        date_fields = ("application_date", "follow_up_date")
        for field in date_fields:
            if field in data and data[field] is not None:
                if not isinstance(data[field], str):
                    return f"{field} must use YYYY-MM-DD."
                try:
                    date.fromisoformat(data[field])
                except ValueError:
                    return f"{field} must be a valid YYYY-MM-DD date."

        if "interview_date" in data and data["interview_date"] is not None:
            value = data["interview_date"]
            if not isinstance(value, str):
                return "interview_date must be an ISO datetime string."
            try:
                datetime.fromisoformat(value.replace("Z", "+00:00"))
            except ValueError:
                return "interview_date must be a valid ISO datetime."

        if "job_url" in data and data["job_url"]:
            if not isinstance(data["job_url"], str):
                return "job_url must be a string."
            try:
                URLValidator()(data["job_url"])
            except ValidationError:
                return "job_url must be a valid URL."

    return None


def apply_payload(record, data, resource, owner):
    for field, value in data.items():
        if field in {"resume_id", "cover_letter_id"}:
            relation = "resume" if field == "resume_id" else "cover_letter"

            if value is None:
                setattr(record, relation, None)
            else:
                model = Resume if relation == "resume" else CoverLetter
                related = get_object_or_404(
                    model, id=value, owner=owner
                )
                setattr(record, relation, related)
            continue

        if field in {"application_date", "follow_up_date"} and value:
            value = date.fromisoformat(value)

        if field == "interview_date" and value:
            value = datetime.fromisoformat(
                value.replace("Z", "+00:00")
            )
            if timezone.is_naive(value):
                value = timezone.make_aware(
                    value, timezone.get_current_timezone()
                )

        if field in {"title", "company", "job_title"} and isinstance(value, str):
            value = value.strip()

        setattr(record, field, value)


@login_required
@require_http_methods(["GET", "POST"])
def resource_list(request, resource):
    if resource not in RESOURCE_CONFIG:
        return JsonResponse({"error": "Unknown resource."}, status=404)

    config = RESOURCE_CONFIG[resource]
    model = config["model"]

    if request.method == "GET":
        queryset = model.objects.filter(owner=request.user)

        query = request.GET.get("q", "").strip()
        if query:
            condition = Q()
            for field in config["search"]:
                condition |= Q(**{f"{field}__icontains": query})
            queryset = queryset.filter(condition)

        status = request.GET.get("status")
        if status and resource == "applications":
            if status not in JobApplication.Status.values:
                return JsonResponse(
                    {"error": "Invalid status."}, status=400
                )
            queryset = queryset.filter(status=status)

        archived = request.GET.get("archived")
        if archived is not None:
            if archived not in ("true", "false"):
                return JsonResponse(
                    {"error": "archived must be true or false."},
                    status=400,
                )
            queryset = queryset.filter(is_archived=(archived == "true"))

        return JsonResponse({
            "count": queryset.count(),
            "results": [
                serialize(item, resource) for item in queryset
            ],
        })

    data, error = parse_json(request)
    if error:
        return error

    message = validate_payload(resource, data, creating=True)
    if message:
        return JsonResponse({"error": message}, status=400)

    record = model(owner=request.user)

    try:
        apply_payload(record, data, resource, request.user)
        record.full_clean(exclude=["owner", "created_at", "updated_at"])
        record.save()
    except (ValidationError, ValueError) as exc:
        messages = exc.messages if isinstance(exc, ValidationError) else [str(exc)]
        return JsonResponse({"error": messages}, status=400)
    except IntegrityError:
        return JsonResponse(
            {"error": "Record conflicts with existing data."}, status=409
        )

    return JsonResponse(serialize(record, resource), status=201)


@login_required
@require_http_methods(["GET", "PATCH", "DELETE"])
def resource_detail(request, resource, record_id):
    if resource not in RESOURCE_CONFIG:
        return JsonResponse({"error": "Unknown resource."}, status=404)

    config = RESOURCE_CONFIG[resource]
    model = config["model"]
    record = get_object_or_404(
        model, id=record_id, owner=request.user
    )

    if request.method == "GET":
        return JsonResponse(serialize(record, resource))

    if request.method == "DELETE":
        record.delete()
        return JsonResponse({"message": "Record deleted."})

    data, error = parse_json(request)
    if error:
        return error

    if not data:
        return JsonResponse(
            {"error": "Provide fields to update."}, status=400
        )

    message = validate_payload(resource, data)
    if message:
        return JsonResponse({"error": message}, status=400)

    try:
        apply_payload(record, data, resource, request.user)
        record.full_clean(exclude=["owner", "created_at", "updated_at"])
        record.save()
    except (ValidationError, ValueError) as exc:
        messages = exc.messages if isinstance(exc, ValidationError) else [str(exc)]
        return JsonResponse({"error": messages}, status=400)
    except IntegrityError:
        return JsonResponse(
            {"error": "Record conflicts with existing data."}, status=409
        )

    return JsonResponse(serialize(record, resource))
