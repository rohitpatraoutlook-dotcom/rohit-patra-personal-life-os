import json

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from apps.jobtracker.models import Resume, CoverLetter, JobApplication

User = get_user_model()


class JobTrackerAPITests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user(
            username="job_owner",
            password="Strong-Test-Password-123!",
        )
        self.other = User.objects.create_user(
            username="job_other",
            password="Strong-Test-Password-456!",
        )
        self.client.force_login(self.owner)

    def url(self, resource):
        return reverse("jobtracker_list", args=[resource])

    def detail_url(self, resource, record_id):
        return reverse(
            "jobtracker_detail", args=[resource, record_id]
        )

    def post_json(self, resource, data):
        return self.client.post(
            self.url(resource),
            data=json.dumps(data),
            content_type="application/json",
        )

    def test_create_resume(self):
        response = self.post_json("resumes", {
            "title": "Backend Developer Resume",
            "target_role": "Python Developer",
        })
        self.assertEqual(response.status_code, 201)
        self.assertEqual(Resume.objects.get().owner, self.owner)

    def test_create_cover_letter(self):
        response = self.post_json("cover-letters", {
            "title": "Application Letter",
            "content": "Dear Hiring Manager...",
        })
        self.assertEqual(response.status_code, 201)

    def test_create_job_application(self):
        response = self.post_json("applications", {
            "company": "Example Company",
            "job_title": "Junior Developer",
            "status": "applied",
        })
        self.assertEqual(response.status_code, 201)
        self.assertEqual(JobApplication.objects.get().owner, self.owner)

    def test_missing_required_fields_rejected(self):
        response = self.post_json("applications", {
            "company": "Example Company",
        })
        self.assertEqual(response.status_code, 400)

    def test_invalid_status_rejected(self):
        response = self.post_json("applications", {
            "company": "Example",
            "job_title": "Developer",
            "status": "hired_immediately",
        })
        self.assertEqual(response.status_code, 400)

    def test_private_list_is_owner_scoped(self):
        Resume.objects.create(owner=self.owner, title="Mine")
        Resume.objects.create(owner=self.other, title="Other")
        response = self.client.get(self.url("resumes"))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["count"], 1)

    def test_other_user_cannot_read_or_update_resume(self):
        resume = Resume.objects.create(
            owner=self.other, title="Private Resume"
        )
        url = self.detail_url("resumes", resume.id)
        self.assertEqual(self.client.get(url).status_code, 404)

        response = self.client.patch(
            url,
            data=json.dumps({"title": "Changed"}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 404)
        resume.refresh_from_db()
        self.assertEqual(resume.title, "Private Resume")

    def test_update_application_status(self):
        application = JobApplication.objects.create(
            owner=self.owner,
            company="Example",
            job_title="Developer",
        )
        response = self.client.patch(
            self.detail_url("applications", application.id),
            data=json.dumps({"status": "interview"}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 200)
        application.refresh_from_db()
        self.assertEqual(application.status, "interview")

    def test_delete_cover_letter(self):
        letter = CoverLetter.objects.create(
            owner=self.owner,
            title="Delete me",
            content="Draft",
        )
        response = self.client.delete(
            self.detail_url("cover-letters", letter.id)
        )
        self.assertEqual(response.status_code, 200)
        self.assertFalse(CoverLetter.objects.filter(id=letter.id).exists())

    def test_search_applications(self):
        JobApplication.objects.create(
            owner=self.owner,
            company="Fortune Example",
            job_title="Developer",
        )
        JobApplication.objects.create(
            owner=self.owner,
            company="Other Company",
            job_title="Designer",
        )
        response = self.client.get(
            self.url("applications"), {"q": "Fortune"}
        )
        self.assertEqual(response.json()["count"], 1)

    def test_invalid_url_rejected(self):
        response = self.post_json("applications", {
            "company": "Example",
            "job_title": "Developer",
            "job_url": "not-a-url",
        })
        self.assertEqual(response.status_code, 400)

    def test_application_cannot_link_another_users_resume(self):
        foreign_resume = Resume.objects.create(
            owner=self.other, title="Foreign Resume"
        )
        response = self.post_json("applications", {
            "company": "Example",
            "job_title": "Developer",
            "resume_id": foreign_resume.id,
        })
        self.assertEqual(response.status_code, 404)

    def test_unauthenticated_access_requires_login(self):
        self.client.logout()
        response = self.client.get(self.url("applications"))
        self.assertEqual(response.status_code, 302)
