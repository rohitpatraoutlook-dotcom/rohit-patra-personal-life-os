from django.urls import path
from . import views

urlpatterns = [
    path(
        "<str:resource>/",
        views.resource_list,
        name="jobtracker_list",
    ),
    path(
        "<str:resource>/<int:record_id>/",
        views.resource_detail,
        name="jobtracker_detail",
    ),
]
