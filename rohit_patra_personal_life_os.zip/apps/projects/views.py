import json

from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.views.decorators.http import require_http_methods

from .models import Project, Skill


def parse_body(request):
    try:
        data = json.loads(request.body or b"{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None, JsonResponse({"error": "Invalid JSON."}, status=400)

    if not isinstance(data, dict):
        return None, JsonResponse(
            {"error": "JSON body must be an object."}, status=400
        )

    return data, None


def project_data(project):
    return {
        "id": project.id,
        "title": project.title,
        "description": project.description,
        "technologies": project.technologies,
        "achievements": project.achievements,
        "repository_url": project.repository_url,
        "live_url": project.live_url,
        "status": project.status,
        "progress": project.progress,
        "is_public": project.is_public,
        "start_date": (
            project.start_date.isoformat() if project.start_date else None
        ),
        "end_date": (
            project.end_date.isoformat() if project.end_date else None
        ),
        "created_at": project.created_at.isoformat(),
        "updated_at": project.updated_at.isoformat(),
    }


def skill_data(skill):
    return {
        "id": skill.id,
        "name": skill.name,
        "category": skill.category,
        "proficiency": skill.proficiency,
        "years_experience": skill.years_experience,
        "description": skill.description,
        "is_public": skill.is_public,
        "created_at": skill.created_at.isoformat(),
        "updated_at": skill.updated_at.isoformat(),
    }


PROJECT_FIELDS = {
    "title", "description", "technologies", "achievements",
    "repository_url", "live_url", "status", "progress",
    "is_public", "start_date", "end_date",
}

SKILL_FIELDS = {
    "name", "category", "proficiency", "years_experience",
    "description", "is_public",
}


def validate_project(data, creating=False):
    unknown = set(data) - PROJECT_FIELDS
    if unknown:
        return f"Unknown fields: {', '.join(sorted(unknown))}"

    if creating and not isinstance(data.get("title"), str):
        return "Title is required."

    if "title" in data:
        if not isinstance(data["title"], str) or not data["title"].strip():
            return "Title must be a non-empty string."
        if len(data["title"].strip()) > 200:
            return "Title cannot exceed 200 characters."

    for field, limit in (
        ("description", None),
        ("technologies", 500),
        ("achievements", None),
    ):
        if field in data:
            value = data[field]
            if not isinstance(value, str):
                return f"{field} must be a string."
            if limit is not None and len(value) > limit:
                return f"{field} cannot exceed {limit} characters."

    for field in ("repository_url", "live_url"):
        if field in data:
            value = data[field]
            if not isinstance(value, str):
                return f"{field} must be a string."
            if value:
                from django.core.validators import URLValidator
                from django.core.exceptions import ValidationError
                try:
                    URLValidator()(value)
                except ValidationError:
                    return f"{field} must be a valid URL."

    if "status" in data and data["status"] not in Project.Status.values:
        return "Invalid project status."

    if "progress" in data:
        value = data["progress"]
        if type(value) is not int or not 0 <= value <= 100:
            return "Progress must be an integer between 0 and 100."

    if "is_public" in data and type(data["is_public"]) is not bool:
        return "is_public must be true or false."

    for field in ("start_date", "end_date"):
        if field in data and data[field] is not None:
            value = data[field]
            if not isinstance(value, str):
                return f"{field} must be YYYY-MM-DD or null."
            from datetime import date
            try:
                date.fromisoformat(value)
            except ValueError:
                return f"{field} must be a valid YYYY-MM-DD date."

    return None


def validate_skill(data, creating=False):
    unknown = set(data) - SKILL_FIELDS
    if unknown:
        return f"Unknown fields: {', '.join(sorted(unknown))}"

    if creating and not isinstance(data.get("name"), str):
        return "Skill name is required."

    if "name" in data:
        if not isinstance(data["name"], str) or not data["name"].strip():
            return "Skill name must be a non-empty string."
        if len(data["name"].strip()) > 100:
            return "Skill name cannot exceed 100 characters."

    for field, limit in (("category", 100), ("description", None)):
        if field in data:
            value = data[field]
            if not isinstance(value, str):
                return f"{field} must be a string."
            if limit is not None and len(value) > limit:
                return f"{field} cannot exceed {limit} characters."

    if "proficiency" in data:
        if data["proficiency"] not in Skill.Proficiency.values:
            return "Invalid proficiency level."

    if "years_experience" in data:
        value = data["years_experience"]
        if type(value) is not int or not 0 <= value <= 80:
            return "years_experience must be an integer between 0 and 80."

    if "is_public" in data and type(data["is_public"]) is not bool:
        return "is_public must be true or false."

    return None


def apply_fields(obj, data):
    for field, value in data.items():
        if field in ("title", "name"):
            value = value.strip()
        if field in ("start_date", "end_date") and value:
            from datetime import date
            value = date.fromisoformat(value)
        setattr(obj, field, value)


@login_required
@require_http_methods(["GET", "POST"])
def projects_list(request):
    if request.method == "GET":
        queryset = Project.objects.filter(owner=request.user)
        query = request.GET.get("q", "").strip()
        if query:
            queryset = queryset.filter(
                Q(title__icontains=query)
                | Q(description__icontains=query)
                | Q(technologies__icontains=query)
            )

        status = request.GET.get("status")
        if status:
            if status not in Project.Status.values:
                return JsonResponse({"error": "Invalid status."}, status=400)
            queryset = queryset.filter(status=status)

        return JsonResponse({
            "count": queryset.count(),
            "results": [project_data(item) for item in queryset],
        })

    data, error = parse_body(request)
    if error:
        return error
    message = validate_project(data, creating=True)
    if message:
        return JsonResponse({"error": message}, status=400)

    project = Project(owner=request.user)
    apply_fields(project, data)
    project.save()
    return JsonResponse(project_data(project), status=201)


@login_required
@require_http_methods(["GET", "PATCH", "DELETE"])
def project_detail(request, project_id):
    project = get_object_or_404(Project, id=project_id, owner=request.user)

    if request.method == "GET":
        return JsonResponse(project_data(project))

    if request.method == "DELETE":
        project.delete()
        return JsonResponse({"message": "Project deleted."})

    data, error = parse_body(request)
    if error:
        return error
    if not data:
        return JsonResponse({"error": "Provide fields to update."}, status=400)

    message = validate_project(data)
    if message:
        return JsonResponse({"error": message}, status=400)

    apply_fields(project, data)
    project.save()
    return JsonResponse(project_data(project))


@login_required
@require_http_methods(["GET", "POST"])
def skills_list(request):
    if request.method == "GET":
        queryset = Skill.objects.filter(owner=request.user)
        query = request.GET.get("q", "").strip()
        if query:
            queryset = queryset.filter(
                Q(name__icontains=query)
                | Q(category__icontains=query)
                | Q(description__icontains=query)
            )

        return JsonResponse({
            "count": queryset.count(),
            "results": [skill_data(item) for item in queryset],
        })

    data, error = parse_body(request)
    if error:
        return error
    message = validate_skill(data, creating=True)
    if message:
        return JsonResponse({"error": message}, status=400)

    skill = Skill(owner=request.user)
    apply_fields(skill, data)
    try:
        skill.save()
    except Exception as exc:
        from django.db import IntegrityError
        if isinstance(exc, IntegrityError):
            return JsonResponse(
                {"error": "This skill already exists."}, status=409
            )
        raise

    return JsonResponse(skill_data(skill), status=201)


@login_required
@require_http_methods(["GET", "PATCH", "DELETE"])
def skill_detail(request, skill_id):
    skill = get_object_or_404(Skill, id=skill_id, owner=request.user)

    if request.method == "GET":
        return JsonResponse(skill_data(skill))

    if request.method == "DELETE":
        skill.delete()
        return JsonResponse({"message": "Skill deleted."})

    data, error = parse_body(request)
    if error:
        return error
    if not data:
        return JsonResponse({"error": "Provide fields to update."}, status=400)

    message = validate_skill(data)
    if message:
        return JsonResponse({"error": message}, status=400)

    apply_fields(skill, data)
    try:
        skill.save()
    except Exception as exc:
        from django.db import IntegrityError
        if isinstance(exc, IntegrityError):
            return JsonResponse(
                {"error": "This skill already exists."}, status=409
            )
        raise

    return JsonResponse(skill_data(skill))


@require_http_methods(["GET"])
def public_projects(request):
    queryset = Project.objects.filter(
        is_public=True, status=Project.Status.COMPLETED
    )
    return JsonResponse({
        "count": queryset.count(),
        "results": [project_data(item) for item in queryset],
    })


@require_http_methods(["GET"])
def public_skills(request):
    queryset = Skill.objects.filter(is_public=True)
    return JsonResponse({
        "count": queryset.count(),
        "results": [skill_data(item) for item in queryset],
    })
