from django.contrib import admin
from .models import Project, Skill


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = (
        "title", "owner", "status", "progress", "is_public"
    )
    list_filter = ("status", "is_public")
    search_fields = ("title", "description", "technologies")


@admin.register(Skill)
class SkillAdmin(admin.ModelAdmin):
    list_display = (
        "name", "owner", "category", "proficiency", "is_public"
    )
    list_filter = ("category", "proficiency", "is_public")
    search_fields = ("name", "category", "description")
