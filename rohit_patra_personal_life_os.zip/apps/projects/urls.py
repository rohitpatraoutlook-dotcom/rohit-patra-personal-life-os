from django.urls import path
from . import views

urlpatterns = [
    path("projects/", views.projects_list, name="projects_list"),
    path(
        "projects/<int:project_id>/",
        views.project_detail,
        name="project_detail",
    ),
    path("skills/", views.skills_list, name="skills_list"),
    path(
        "skills/<int:skill_id>/",
        views.skill_detail,
        name="skill_detail",
    ),
    path("public/projects/", views.public_projects, name="public_projects"),
    path("public/skills/", views.public_skills, name="public_skills"),
]
