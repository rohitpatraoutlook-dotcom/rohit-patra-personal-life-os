import json

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from apps.projects.models import Project, Skill

User = get_user_model()


class ProjectsSkillsAPITests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user(
            username="career_owner", password="Strong-Password-123!"
        )
        self.other = User.objects.create_user(
            username="career_other", password="Strong-Password-456!"
        )
        self.client.force_login(self.owner)

    def send_json(self, method, url, data):
        return getattr(self.client, method)(
            url,
            data=json.dumps(data),
            content_type="application/json",
        )

    def test_create_project_private_by_default(self):
        response = self.send_json("post", reverse("projects_list"), {
            "title": "Life OS",
            "description": "Personal productivity platform",
        })
        self.assertEqual(response.status_code, 201)
        project = Project.objects.get()
        self.assertEqual(project.owner, self.owner)
        self.assertFalse(project.is_public)

    def test_invalid_project_progress_rejected(self):
        response = self.send_json("post", reverse("projects_list"), {
            "title": "Bad progress",
            "progress": 150,
        })
        self.assertEqual(response.status_code, 400)

    def test_project_search(self):
        Project.objects.create(
            owner=self.owner, title="Django API", technologies="Python"
        )
        Project.objects.create(owner=self.owner, title="Portfolio")
        response = self.client.get(reverse("projects_list"), {"q": "Django"})
        self.assertEqual(response.json()["count"], 1)

    def test_projects_are_owner_scoped(self):
        Project.objects.create(owner=self.owner, title="Mine")
        Project.objects.create(owner=self.other, title="Secret")
        response = self.client.get(reverse("projects_list"))
        self.assertEqual(response.json()["count"], 1)

    def test_other_user_cannot_access_project(self):
        project = Project.objects.create(owner=self.other, title="Secret")
        url = reverse("project_detail", args=[project.id])
        self.assertEqual(self.client.get(url).status_code, 404)
        self.assertEqual(
            self.send_json("patch", url, {"title": "Hijacked"}).status_code,
            404,
        )
        self.assertEqual(self.client.delete(url).status_code, 404)

    def test_update_project_progress(self):
        project = Project.objects.create(owner=self.owner, title="API")
        response = self.send_json(
            "patch",
            reverse("project_detail", args=[project.id]),
            {"progress": 75, "status": "in_progress"},
        )
        self.assertEqual(response.status_code, 200)
        project.refresh_from_db()
        self.assertEqual(project.progress, 75)

    def test_delete_project(self):
        project = Project.objects.create(owner=self.owner, title="Delete")
        response = self.client.delete(
            reverse("project_detail", args=[project.id])
        )
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Project.objects.filter(id=project.id).exists())

    def test_public_endpoint_only_returns_completed_public_projects(self):
        Project.objects.create(
            owner=self.owner, title="Published",
            status="completed", is_public=True,
        )
        Project.objects.create(
            owner=self.owner, title="Private",
            status="completed", is_public=False,
        )
        Project.objects.create(
            owner=self.owner, title="Ongoing",
            status="in_progress", is_public=True,
        )
        response = self.client.get(reverse("public_projects"))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["count"], 1)
        self.assertEqual(response.json()["results"][0]["title"], "Published")

    def test_create_skill(self):
        response = self.send_json("post", reverse("skills_list"), {
            "name": "Python",
            "proficiency": "intermediate",
            "years_experience": 2,
        })
        self.assertEqual(response.status_code, 201)
        skill = Skill.objects.get()
        self.assertEqual(skill.owner, self.owner)
        self.assertFalse(skill.is_public)

    def test_invalid_skill_proficiency_rejected(self):
        response = self.send_json("post", reverse("skills_list"), {
            "name": "Python",
            "proficiency": "legendary",
        })
        self.assertEqual(response.status_code, 400)

    def test_duplicate_skill_rejected(self):
        Skill.objects.create(owner=self.owner, name="Python")
        response = self.send_json("post", reverse("skills_list"), {
            "name": "Python",
        })
        self.assertEqual(response.status_code, 409)

    def test_skills_are_owner_scoped(self):
        Skill.objects.create(owner=self.owner, name="Python")
        Skill.objects.create(owner=self.other, name="Secret skill")
        response = self.client.get(reverse("skills_list"))
        self.assertEqual(response.json()["count"], 1)

    def test_other_user_cannot_modify_skill(self):
        skill = Skill.objects.create(owner=self.other, name="Private")
        response = self.send_json(
            "patch", reverse("skill_detail", args=[skill.id]),
            {"name": "Modified"},
        )
        self.assertEqual(response.status_code, 404)
        skill.refresh_from_db()
        self.assertEqual(skill.name, "Private")

    def test_delete_skill(self):
        skill = Skill.objects.create(owner=self.owner, name="Remove")
        response = self.client.delete(
            reverse("skill_detail", args=[skill.id])
        )
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Skill.objects.filter(id=skill.id).exists())

    def test_public_skills_only_include_published_skills(self):
        Skill.objects.create(
            owner=self.owner, name="Public skill", is_public=True
        )
        Skill.objects.create(
            owner=self.owner, name="Private skill", is_public=False
        )
        response = self.client.get(reverse("public_skills"))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["count"], 1)

    def test_unauthenticated_private_api_requires_login(self):
        self.client.logout()
        response = self.client.get(reverse("projects_list"))
        self.assertEqual(response.status_code, 302)
